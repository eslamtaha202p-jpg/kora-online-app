# كورة اونلاين - مباريات اليوم v0.6.0

Flutter Android app for Arabic football scores using the configured web data endpoints directly during development.

Core flows in this build:
- Matches by date and live matches
- Search and status filters
- Competition catalog and competition pages
- Standings and top scorers
- Match summary, events, lineups, stats, H2H and predictions
- Team squad and player profile
- Favorites
- Persistent functional settings and auto refresh

Package ID used by the GitHub build workflow: `com.koraonline.matches`
