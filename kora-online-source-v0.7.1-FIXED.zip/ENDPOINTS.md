# Endpoints connected in v0.1.0

- `/web/games/current/` → matches list
- `/web/games/featured/` → featured match
- `/web/stats/` → top scorers
- `/web/competitions/top/` → competition cards
- `/web/competitors/top/` → team cards
- `/web/athletes/top/` → player cards

Pending capture/connection:
- standings
- match events/timeline
- lineups
- game detailed stats
- player profile details
- team squad/details
- news
