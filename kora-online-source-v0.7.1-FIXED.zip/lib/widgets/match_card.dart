import 'package:flutter/material.dart';

import '../core/app_theme.dart';
import '../models/match.dart';
import '../models/team.dart';
import 'network_logo.dart';

class MatchCard extends StatelessWidget {
  final MatchItem match;
  final VoidCallback? onTap;
  final bool compact;

  const MatchCard({super.key, required this.match, this.onTap, this.compact = false});

  @override
  Widget build(BuildContext context) {
    final live = match.isLive;
    final hasScore = match.home.score != null && match.away.score != null;
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(18),
      child: Ink(
        padding: EdgeInsets.all(compact ? 12 : 15),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: live ? const Color(0x6658E6A8) : AppColors.border),
        ),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    match.competitionName,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: AppColors.muted, fontSize: 11, fontWeight: FontWeight.w700),
                  ),
                ),
                if (live)
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(color: AppColors.danger.withValues(alpha: .14), borderRadius: BorderRadius.circular(99)),
                    child: const Text('مباشر', style: TextStyle(color: AppColors.danger, fontSize: 10, fontWeight: FontWeight.w900)),
                  )
                else
                  Text(match.statusText, style: const TextStyle(color: AppColors.muted, fontSize: 10)),
              ],
            ),
            SizedBox(height: compact ? 10 : 14),
            Row(
              children: [
                Expanded(child: _Team(team: match.home, compact: compact)),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  child: Column(
                    children: [
                      Text(
                        hasScore ? '${match.home.score}  -  ${match.away.score}' : match.kickoffLabel,
                        style: TextStyle(fontSize: compact ? 20 : 24, fontWeight: FontWeight.w900),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        live ? (match.gameTimeDisplay.isNotEmpty ? match.gameTimeDisplay : '${match.gameTime}\'') : match.shortStatusText,
                        style: TextStyle(color: live ? AppColors.success : AppColors.muted, fontSize: 10, fontWeight: FontWeight.w700),
                      ),
                    ],
                  ),
                ),
                Expanded(child: _Team(team: match.away, compact: compact)),
              ],
            ),
            if (!compact && (match.roundName.isNotEmpty || match.aggregateText.isNotEmpty)) ...[
              const SizedBox(height: 10),
              Text(
                [match.roundName, match.stageName, match.aggregateText].where((e) => e.isNotEmpty).join(' · '),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: AppColors.muted, fontSize: 10),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _Team extends StatelessWidget {
  final Team team;
  final bool compact;
  const _Team({required this.team, required this.compact});

  @override
  Widget build(BuildContext context) => Column(
        children: [
          NetworkLogo(url: team.logoUrl, size: compact ? 38 : 46),
          const SizedBox(height: 7),
          Text(
            team.name,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: compact ? 10 : 11, fontWeight: FontWeight.w800),
          ),
        ],
      );
}
