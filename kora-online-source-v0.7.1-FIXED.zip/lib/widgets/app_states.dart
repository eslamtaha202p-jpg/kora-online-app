import 'package:flutter/material.dart';

import '../core/app_theme.dart';

class AppLoading extends StatelessWidget {
  final String text;
  const AppLoading({super.key, this.text = 'جاري تحميل البيانات...'});

  @override
  Widget build(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const CircularProgressIndicator(color: AppColors.primary),
            const SizedBox(height: 14),
            Text(text, style: const TextStyle(color: AppColors.muted)),
          ]),
        ),
      );
}

class AppError extends StatelessWidget {
  final Object error;
  final Future<void> Function()? onRetry;
  const AppError({super.key, required this.error, this.onRetry});

  @override
  Widget build(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.all(26),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Icon(Icons.wifi_off_rounded, size: 48, color: AppColors.danger),
            const SizedBox(height: 12),
            const Text('تعذر تحميل البيانات', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
            const SizedBox(height: 7),
            Text('$error', textAlign: TextAlign.center, style: const TextStyle(color: AppColors.muted, height: 1.5)),
            if (onRetry != null) ...[
              const SizedBox(height: 14),
              FilledButton.icon(onPressed: () => onRetry!(), icon: const Icon(Icons.refresh), label: const Text('إعادة المحاولة')),
            ],
          ]),
        ),
      );
}

class EmptyState extends StatelessWidget {
  final String text;
  final IconData icon;
  const EmptyState({super.key, required this.text, this.icon = Icons.sports_soccer_outlined});

  @override
  Widget build(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(icon, size: 44, color: AppColors.muted),
            const SizedBox(height: 10),
            Text(text, textAlign: TextAlign.center, style: const TextStyle(color: AppColors.muted)),
          ]),
        ),
      );
}
