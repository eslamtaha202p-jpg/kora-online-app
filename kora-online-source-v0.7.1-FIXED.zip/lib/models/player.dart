import '../core/api_config.dart';

class PlayerItem {
  final int id;
  final String name;
  final String shortName;
  final String clubName;
  final String nationalityName;
  final String positionName;
  final int age;
  final int imageVersion;
  final int jerseyNumber;

  const PlayerItem({
    required this.id,
    required this.name,
    required this.shortName,
    required this.clubName,
    required this.nationalityName,
    required this.positionName,
    required this.age,
    required this.imageVersion,
    this.jerseyNumber = 0,
  });

  factory PlayerItem.fromJson(Map<String, dynamic> json) {
    final athlete = _map(json['athlete']).isNotEmpty ? _map(json['athlete']) : json;
    final position = _map(athlete['position']);
    final competitor = _map(athlete['competitor'] ?? json['competitor']);
    return PlayerItem(
      id: _toInt(athlete['id'] ?? athlete['athleteId']),
      name: (athlete['name'] ?? athlete['fullName'] ?? 'لاعب').toString(),
      shortName: (athlete['shortName'] ?? athlete['name'] ?? 'لاعب').toString(),
      clubName: (athlete['clubName'] ?? competitor['name'] ?? json['competitorName'] ?? '').toString(),
      nationalityName: (athlete['nationalityName'] ?? _map(athlete['country'])['name'] ?? '').toString(),
      positionName: (position['name'] ?? athlete['positionName'] ?? '').toString(),
      age: _toInt(athlete['age']),
      imageVersion: _toInt(athlete['imageVersion'], fallback: 1),
      jerseyNumber: _toInt(json['jerseyNumber'] ?? athlete['jerseyNumber']),
    );
  }

  String get imageUrl => ApiConfig.athletePhoto(id: id, imageVersion: imageVersion);

  static Map<String, dynamic> _map(dynamic value) {
    if (value is Map<String, dynamic>) return value;
    if (value is Map) return value.map((k, v) => MapEntry('$k', v));
    return const <String, dynamic>{};
  }

  static int _toInt(dynamic value, {int fallback = 0}) {
    if (value is num) return value.toInt();
    return int.tryParse('$value') ?? fallback;
  }
}
