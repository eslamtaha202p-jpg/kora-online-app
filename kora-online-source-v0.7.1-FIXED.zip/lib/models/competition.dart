import '../core/api_config.dart';

class Competition {
  final int id;
  final String name;
  final String nameForUrl;
  final int imageVersion;
  final int currentSeasonNum;
  final bool hasStandings;
  final bool hasBrackets;
  final int countryId;

  const Competition({
    required this.id,
    required this.name,
    required this.nameForUrl,
    required this.imageVersion,
    this.currentSeasonNum = 0,
    this.hasStandings = false,
    this.hasBrackets = false,
    this.countryId = 0,
  });

  factory Competition.fromJson(Map<String, dynamic> json) => Competition(
        id: _toInt(json['id'] ?? json['competitionId']),
        name: (json['name'] ?? json['competitionDisplayName'] ?? json['displayName'] ?? 'بطولة').toString(),
        nameForUrl: (json['nameForURL'] ?? '').toString(),
        imageVersion: _toInt(json['imageVersion'], fallback: 1),
        currentSeasonNum: _toInt(json['currentSeasonNum'] ?? json['seasonNum']),
        hasStandings: json['hasStandings'] == true,
        hasBrackets: json['hasBrackets'] == true,
        countryId: _toInt(json['countryId']),
      );

  String get logoUrl => ApiConfig.competitionLogo(id: id, imageVersion: imageVersion);

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'nameForURL': nameForUrl,
        'imageVersion': imageVersion,
        'currentSeasonNum': currentSeasonNum,
        'hasStandings': hasStandings,
        'hasBrackets': hasBrackets,
        'countryId': countryId,
      };

  static int _toInt(dynamic value, {int fallback = 0}) {
    if (value is num) return value.toInt();
    return int.tryParse('$value') ?? fallback;
  }
}
