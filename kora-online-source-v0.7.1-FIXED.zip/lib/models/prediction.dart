class PredictionOption {
  final int number;
  final String name;
  final int count;
  final int percentage;

  const PredictionOption({required this.number, required this.name, required this.count, required this.percentage});

  factory PredictionOption.fromJson(Map<String, dynamic> json) {
    final vote = _map(json['vote']);
    return PredictionOption(
      number: _toInt(json['num'] ?? json['id']),
      name: (json['name'] ?? json['title'] ?? '').toString(),
      count: _toInt(vote['count'] ?? json['count']),
      percentage: _toInt(vote['percentage'] ?? json['percentage']),
    );
  }
}

class MatchPrediction {
  final int gameId;
  final int id;
  final String title;
  final int totalVotes;
  final List<PredictionOption> options;

  const MatchPrediction({required this.gameId, required this.id, required this.title, required this.totalVotes, required this.options});

  static MatchPrediction? fromGameJson(Map<String, dynamic> game) {
    final promoted = _map(game['promotedPredictions']);
    var predictions = _list(promoted['predictions']);
    if (predictions.isEmpty) predictions = _list(game['predictions']);
    if (predictions.isEmpty) return null;
    final raw = predictions.first;
    final options = _list(raw['options']).map(PredictionOption.fromJson).where((e) => e.name.isNotEmpty).toList(growable: false);
    if (options.isEmpty) return null;
    return MatchPrediction(
      gameId: _toInt(game['id'] ?? game['gameId']),
      id: _toInt(raw['id']),
      title: (raw['title'] ?? raw['question'] ?? 'من سيفوز؟').toString(),
      totalVotes: _toInt(raw['totalVotes']),
      options: options,
    );
  }
}

Map<String, dynamic> _map(dynamic value) {
  if (value is Map<String, dynamic>) return value;
  if (value is Map) return value.map((k, v) => MapEntry('$k', v));
  return const <String, dynamic>{};
}

List<Map<String, dynamic>> _list(dynamic value) {
  if (value is! List) return const [];
  return value.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList(growable: false);
}

int _toInt(dynamic value) {
  if (value is num) return value.toInt();
  return int.tryParse('$value') ?? 0;
}
