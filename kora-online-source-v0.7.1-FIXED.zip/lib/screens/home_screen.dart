import 'dart:async';

import 'package:flutter/material.dart';

import '../core/app_identity.dart';
import '../core/app_theme.dart';
import '../data/favorites_store.dart';
import '../data/settings_store.dart';
import '../data/sports_repository.dart';
import '../models/competition.dart';
import '../models/match.dart';
import '../widgets/app_states.dart';
import '../widgets/match_card.dart';
import 'competition_details_screen.dart';
import 'match_details_screen.dart';

class HomeScreen extends StatefulWidget {
  final SportsRepository repository;
  final FavoritesStore favorites;
  final SettingsStore settings;
  const HomeScreen({super.key, required this.repository, required this.favorites, required this.settings});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  DateTime date = DateTime.now();
  bool loading = true;
  Object? error;
  List<MatchItem> matches = const [];
  List<MatchItem> live = const [];
  String query = '';
  int filter = 0;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    widget.settings.addListener(_settingsChanged);
    _scheduleRefresh();
    _load();
  }

  @override
  void dispose() {
    _timer?.cancel();
    widget.settings.removeListener(_settingsChanged);
    super.dispose();
  }

  void _settingsChanged() {
    _scheduleRefresh();
    if (mounted) setState(() {});
  }

  void _scheduleRefresh() {
    _timer?.cancel();
    if (!widget.settings.autoRefresh) return;
    _timer = Timer.periodic(Duration(seconds: widget.settings.refreshSeconds), (_) {
      if (_isToday(date) && mounted) _load(silent: true);
    });
  }

  Future<void> _load({bool silent = false}) async {
    if (!silent) setState(() { loading = true; error = null; });
    try {
      final values = await Future.wait([
        widget.repository.fetchMatchesForDate(date),
        widget.repository.fetchLiveMatches(),
      ]);
      if (!mounted) return;
      setState(() {
        matches = values[0];
        live = values[1];
        loading = false;
        error = null;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() { error = e; loading = false; });
    }
  }

  List<MatchItem> get visibleMatches {
    Iterable<MatchItem> data = matches;
    if (filter == 1) data = data.where((m) => m.isLive);
    if (filter == 2) data = data.where((m) => m.isUpcoming);
    if (filter == 3) data = data.where((m) => m.isFinished);
    final q = query.trim().toLowerCase();
    if (q.isNotEmpty) {
      data = data.where((m) => '${m.home.name} ${m.away.name} ${m.competitionName}'.toLowerCase().contains(q));
    }
    final list = data.toList(growable: false);
    if (widget.settings.liveFirst) {
      list.sort((a, b) {
        if (a.isLive != b.isLive) return a.isLive ? -1 : 1;
        final x = a.startTime?.millisecondsSinceEpoch ?? 0;
        final y = b.startTime?.millisecondsSinceEpoch ?? 0;
        return x.compareTo(y);
      });
    }
    return list;
  }

  List<Competition> get competitions {
    final seen = <int>{};
    final out = <Competition>[];
    for (final m in matches) {
      if (m.competitionId == 0 || !seen.add(m.competitionId)) continue;
      out.add(Competition(
        id: m.competitionId,
        name: m.competitionName,
        nameForUrl: '',
        imageVersion: m.competitionImageVersion,
        hasStandings: m.hasStandings,
      ));
    }
    return out.take(10).toList(growable: false);
  }

  void _shiftDate(int days) {
    setState(() => date = DateTime(date.year, date.month, date.day + days));
    _load();
  }

  String _dateLabel(DateTime d) {
    final today = DateTime.now();
    final a = DateTime(d.year, d.month, d.day);
    final b = DateTime(today.year, today.month, today.day);
    final diff = a.difference(b).inDays;
    if (diff == 0) return 'اليوم';
    if (diff == -1) return 'أمس';
    if (diff == 1) return 'غدًا';
    return '${d.day}/${d.month}';
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      bottom: false,
      child: RefreshIndicator(
        onRefresh: _load,
        color: AppColors.primary,
        backgroundColor: AppColors.surface,
        child: CustomScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          slivers: [
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 14, 16, 10),
                child: Row(children: [
                  Container(
                    width: 46,
                    height: 46,
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(colors: [AppColors.primary, AppColors.primaryDeep]),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: const Icon(Icons.sports_soccer_rounded, color: Colors.white),
                  ),
                  const SizedBox(width: 11),
                  const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(AppIdentity.brandName, style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
                    Text(AppIdentity.tagline, style: TextStyle(color: AppColors.muted, fontSize: 10)),
                  ])),
                  IconButton(onPressed: _load, icon: const Icon(Icons.refresh_rounded)),
                ]),
              ),
            ),
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: TextField(
                  onChanged: (v) => setState(() => query = v),
                  decoration: InputDecoration(
                    hintText: 'ابحث عن فريق أو بطولة',
                    prefixIcon: const Icon(Icons.search_rounded),
                    filled: true,
                    fillColor: AppColors.surface,
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
                    enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: const BorderSide(color: AppColors.border)),
                  ),
                ),
              ),
            ),
            SliverToBoxAdapter(child: _DateStrip(date: date, label: _dateLabel(date), onPrev: () => _shiftDate(-1), onNext: () => _shiftDate(1), onToday: () {
              setState(() => date = DateTime.now());
              _load();
            })),
            SliverToBoxAdapter(child: _Filters(value: filter, liveCount: live.length, onChanged: (v) => setState(() => filter = v))),
            if (loading && matches.isEmpty)
              const SliverFillRemaining(child: AppLoading())
            else if (error != null && matches.isEmpty)
              SliverFillRemaining(child: AppError(error: error!, onRetry: _load))
            else ...[
              if (live.isNotEmpty && _isToday(date)) ...[
                const SliverToBoxAdapter(child: _Header(title: 'مباشر الآن')),
                SliverPadding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  sliver: SliverList.separated(
                    itemCount: live.take(3).length,
                    separatorBuilder: (_, __) => const SizedBox(height: 10),
                    itemBuilder: (_, i) => MatchCard(match: live[i], compact: widget.settings.compactCards, onTap: () => _openMatch(live[i])),
                  ),
                ),
              ],
              SliverToBoxAdapter(child: _Header(title: 'مباريات ${_dateLabel(date)}', trailing: '${visibleMatches.length}')),
              if (visibleMatches.isEmpty)
                const SliverToBoxAdapter(child: SizedBox(height: 220, child: EmptyState(text: 'لا توجد مباريات مطابقة')))
              else
                SliverPadding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  sliver: SliverList.separated(
                    itemCount: visibleMatches.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 10),
                    itemBuilder: (_, i) => MatchCard(match: visibleMatches[i], compact: widget.settings.compactCards, onTap: () => _openMatch(visibleMatches[i])),
                  ),
                ),
              if (competitions.isNotEmpty) ...[
                const SliverToBoxAdapter(child: _Header(title: 'بطولات اليوم')),
                SliverToBoxAdapter(
                  child: SizedBox(
                    height: 92,
                    child: ListView.separated(
                      scrollDirection: Axis.horizontal,
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      itemCount: competitions.length,
                      separatorBuilder: (_, __) => const SizedBox(width: 9),
                      itemBuilder: (_, i) {
                        final c = competitions[i];
                        return InkWell(
                          onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => CompetitionDetailsScreen(repository: widget.repository, favorites: widget.favorites, competition: c))),
                          borderRadius: BorderRadius.circular(16),
                          child: Container(
                            width: 145,
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(16), border: Border.all(color: AppColors.border)),
                            child: Center(child: Text(c.name, maxLines: 2, textAlign: TextAlign.center, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 11))),
                          ),
                        );
                      },
                    ),
                  ),
                ),
              ],
              const SliverToBoxAdapter(child: SizedBox(height: 28)),
            ],
          ],
        ),
      ),
    );
  }

  bool _isToday(DateTime d) {
    final n = DateTime.now();
    return d.year == n.year && d.month == n.month && d.day == n.day;
  }

  void _openMatch(MatchItem match) {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => MatchDetailsScreen(repository: widget.repository, favorites: widget.favorites, match: match)));
  }
}

class _DateStrip extends StatelessWidget {
  final DateTime date;
  final String label;
  final VoidCallback onPrev;
  final VoidCallback onNext;
  final VoidCallback onToday;
  const _DateStrip({required this.date, required this.label, required this.onPrev, required this.onNext, required this.onToday});

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 8),
        child: Row(children: [
          IconButton.filledTonal(onPressed: onPrev, icon: const Icon(Icons.chevron_right_rounded)),
          Expanded(
            child: InkWell(
              onTap: onToday,
              borderRadius: BorderRadius.circular(14),
              child: Container(
                padding: const EdgeInsets.symmetric(vertical: 10),
                decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(14), border: Border.all(color: AppColors.border)),
                child: Column(children: [
                  Text(label, style: const TextStyle(fontWeight: FontWeight.w900)),
                  Text('${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}/${date.year}', style: const TextStyle(color: AppColors.muted, fontSize: 10)),
                ]),
              ),
            ),
          ),
          IconButton.filledTonal(onPressed: onNext, icon: const Icon(Icons.chevron_left_rounded)),
        ]),
      );
}

class _Filters extends StatelessWidget {
  final int value;
  final int liveCount;
  final ValueChanged<int> onChanged;
  const _Filters({required this.value, required this.liveCount, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    const labels = ['الكل', 'مباشر', 'قادمة', 'انتهت'];
    return SizedBox(
      height: 52,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 7),
        itemCount: labels.length,
        separatorBuilder: (_, __) => const SizedBox(width: 7),
        itemBuilder: (_, i) => ChoiceChip(
          selected: value == i,
          onSelected: (_) => onChanged(i),
          label: Text(i == 1 && liveCount > 0 ? '${labels[i]} $liveCount' : labels[i]),
        ),
      ),
    );
  }
}

class _Header extends StatelessWidget {
  final String title;
  final String? trailing;
  const _Header({required this.title, this.trailing});

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(18, 18, 18, 9),
        child: Row(children: [
          Expanded(child: Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900))),
          if (trailing != null) Text(trailing!, style: const TextStyle(color: AppColors.primary, fontWeight: FontWeight.w800)),
        ]),
      );
}
