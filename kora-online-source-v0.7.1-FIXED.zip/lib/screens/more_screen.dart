import 'package:flutter/material.dart';

import '../core/app_identity.dart';
import '../core/app_theme.dart';
import '../data/favorites_store.dart';
import '../data/settings_store.dart';

class MoreScreen extends StatefulWidget {
  final SettingsStore settings;
  final FavoritesStore favorites;
  const MoreScreen({super.key, required this.settings, required this.favorites});

  @override
  State<MoreScreen> createState() => _MoreScreenState();
}

class _MoreScreenState extends State<MoreScreen> {
  @override
  void initState() {
    super.initState();
    widget.settings.addListener(_changed);
  }

  @override
  void dispose() {
    widget.settings.removeListener(_changed);
    super.dispose();
  }

  void _changed() {
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.settings;
    return SafeArea(
      bottom: false,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('الإعدادات', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900)),
          const SizedBox(height: 16),
          _SwitchItem(
            icon: Icons.view_agenda_outlined,
            title: 'بطاقات مباريات مضغوطة',
            subtitle: 'اعرض معلومات أكثر في الشاشة',
            value: s.compactCards,
            onChanged: s.setCompactCards,
          ),
          _SwitchItem(
            icon: Icons.bolt_rounded,
            title: 'المباشر أولاً',
            subtitle: 'ترتيب المباريات المباشرة قبل باقي المباريات',
            value: s.liveFirst,
            onChanged: s.setLiveFirst,
          ),
          _SwitchItem(
            icon: Icons.refresh_rounded,
            title: 'تحديث تلقائي',
            subtitle: 'تحديث مباريات اليوم والمباشر تلقائياً',
            value: s.autoRefresh,
            onChanged: s.setAutoRefresh,
          ),
          if (s.autoRefresh)
            Container(
              margin: const EdgeInsets.only(bottom: 8),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(15), border: Border.all(color: AppColors.border)),
              child: Row(
                children: [
                  const Icon(Icons.timer_outlined, color: AppColors.primary),
                  const SizedBox(width: 12),
                  const Expanded(child: Text('مدة التحديث', style: TextStyle(fontWeight: FontWeight.w800))),
                  DropdownButton<int>(
                    value: s.refreshSeconds,
                    underline: const SizedBox.shrink(),
                    items: const [
                      DropdownMenuItem(value: 30, child: Text('30 ثانية')),
                      DropdownMenuItem(value: 60, child: Text('دقيقة')),
                      DropdownMenuItem(value: 120, child: Text('دقيقتان')),
                    ],
                    onChanged: (v) {
                      if (v != null) s.setRefreshSeconds(v);
                    },
                  ),
                ],
              ),
            ),
          _Item(
            icon: Icons.delete_outline_rounded,
            title: 'مسح المفضلة',
            subtitle: 'حذف كل الفرق والبطولات والمباريات المحفوظة',
            onTap: () async {
              final ok = await showDialog<bool>(
                context: context,
                builder: (_) => AlertDialog(
                  title: const Text('مسح المفضلة؟'),
                  content: const Text('سيتم حذف كل العناصر المحفوظة على هذا الجهاز.'),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
                    FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('مسح')),
                  ],
                ),
              );
              if (ok == true) {
                await widget.favorites.clear();
                if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم مسح المفضلة')));
              }
            },
          ),
          _Item(
            icon: Icons.restart_alt_rounded,
            title: 'إعادة الإعدادات',
            subtitle: 'العودة للإعدادات الافتراضية',
            onTap: () async {
              await s.reset();
              if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تمت إعادة الإعدادات')));
            },
          ),
          _Item(
            icon: Icons.info_outline_rounded,
            title: 'عن التطبيق',
            subtitle: 'الإصدار ${AppIdentity.versionName}',
            onTap: () => showAboutDialog(
              context: context,
              applicationName: AppIdentity.storeName,
              applicationVersion: AppIdentity.versionName,
              applicationIcon: const Icon(Icons.sports_soccer_rounded, color: AppColors.primary, size: 42),
              children: const [Text('كورة اونلاين لمتابعة المباريات والبطولات والفرق واللاعبين باللغة العربية.')],
            ),
          ),
        ],
      ),
    );
  }
}

class _SwitchItem extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final bool value;
  final ValueChanged<bool> onChanged;
  const _SwitchItem({required this.icon, required this.title, required this.subtitle, required this.value, required this.onChanged});

  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(bottom: 8),
        decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(15), border: Border.all(color: AppColors.border)),
        child: SwitchListTile(
          value: value,
          onChanged: onChanged,
          secondary: Icon(icon, color: AppColors.primary),
          title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
          subtitle: Text(subtitle, style: const TextStyle(color: AppColors.muted, fontSize: 10)),
        ),
      );
}

class _Item extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;
  const _Item({required this.icon, required this.title, required this.subtitle, required this.onTap});

  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(bottom: 8),
        decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(15), border: Border.all(color: AppColors.border)),
        child: ListTile(
          onTap: onTap,
          leading: Icon(icon, color: AppColors.primary),
          title: Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
          subtitle: Text(subtitle, maxLines: 2, style: const TextStyle(color: AppColors.muted, fontSize: 10)),
          trailing: const Icon(Icons.chevron_left_rounded, color: AppColors.muted),
        ),
      );
}
