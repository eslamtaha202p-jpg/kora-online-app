import 'package:flutter/material.dart';

import '../core/app_theme.dart';
import '../data/favorites_store.dart';
import '../data/sports_repository.dart';
import '../models/team.dart';
import '../widgets/app_states.dart';
import '../widgets/match_card.dart';
import '../widgets/network_logo.dart';
import 'match_details_screen.dart';
import 'player_screen.dart';

class TeamScreen extends StatefulWidget {
  final SportsRepository repository;
  final FavoritesStore favorites;
  final Team initialTeam;
  const TeamScreen({super.key, required this.repository, required this.favorites, required this.initialTeam});

  @override
  State<TeamScreen> createState() => _TeamScreenState();
}

class _TeamScreenState extends State<TeamScreen> {
  bool loading = true;
  Object? error;
  TeamProfileData? data;

  @override
  void initState() {
    super.initState();
    widget.favorites.addListener(_favChanged);
    _load();
  }

  @override
  void dispose() {
    widget.favorites.removeListener(_favChanged);
    super.dispose();
  }

  void _favChanged() { if (mounted) setState(() {}); }

  Future<void> _load() async {
    setState(() { loading = true; error = null; });
    try {
      final result = await widget.repository.fetchTeamProfile(widget.initialTeam.id);
      if (!mounted) return;
      setState(() { data = result; loading = false; });
    } catch (e) {
      if (!mounted) return;
      setState(() { error = e; loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    final team = data?.team ?? widget.initialTeam;
    final fav = widget.favorites.contains('team', team.id);
    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColors.background,
        title: Text(team.name, maxLines: 1, overflow: TextOverflow.ellipsis),
        actions: [
          IconButton(onPressed: () => widget.favorites.toggle(FavoriteRecord.team(team)), icon: Icon(fav ? Icons.star_rounded : Icons.star_border_rounded, color: fav ? AppColors.accent : null)),
          IconButton(onPressed: _load, icon: const Icon(Icons.refresh_rounded)),
        ],
      ),
      body: loading && data == null
          ? const AppLoading(text: 'جاري تحميل الفريق...')
          : error != null && data == null
              ? AppError(error: error!, onRetry: _load)
              : ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    Container(
                      padding: const EdgeInsets.all(18),
                      decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(20), border: Border.all(color: AppColors.border)),
                      child: Column(children: [
                        NetworkLogo(url: team.logoUrl, size: 78),
                        const SizedBox(height: 10),
                        Text(team.name, textAlign: TextAlign.center, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
                        if (team.symbolicName.isNotEmpty) Text(team.symbolicName, style: const TextStyle(color: AppColors.muted, fontSize: 11)),
                      ]),
                    ),
                    const SizedBox(height: 18),
                    const Text('قائمة اللاعبين', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
                    const SizedBox(height: 9),
                    if ((data?.players ?? const []).isEmpty)
                      const SizedBox(height: 130, child: EmptyState(text: 'قائمة اللاعبين غير متاحة من المصدر'))
                    else
                      ...(data!.players.map((p) => Container(
                        margin: const EdgeInsets.only(bottom: 7),
                        decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(14), border: Border.all(color: AppColors.border)),
                        child: ListTile(
                          onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => PlayerScreen(repository: widget.repository, favorites: widget.favorites, athleteId: p.id, initialName: p.name))),
                          leading: CircleAvatar(backgroundColor: AppColors.surface2, backgroundImage: NetworkImage(p.imageUrl), onBackgroundImageError: (_, __) {}),
                          title: Text(p.name, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12)),
                          subtitle: Text([p.positionName, p.jerseyNumber == 0 ? '' : '#${p.jerseyNumber}'].where((e) => e.isNotEmpty).join(' · '), style: const TextStyle(color: AppColors.muted, fontSize: 9)),
                          trailing: const Icon(Icons.chevron_left_rounded, color: AppColors.muted),
                        ),
                      ))),
                    if ((data?.matches ?? const []).isNotEmpty) ...[
                      const SizedBox(height: 18),
                      const Text('مباريات الفريق', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
                      const SizedBox(height: 9),
                      ...data!.matches.take(10).map((m) => Padding(
                        padding: const EdgeInsets.only(bottom: 9),
                        child: MatchCard(match: m, compact: true, onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => MatchDetailsScreen(repository: widget.repository, favorites: widget.favorites, match: m)))),
                      )),
                    ],
                  ],
                ),
    );
  }
}
