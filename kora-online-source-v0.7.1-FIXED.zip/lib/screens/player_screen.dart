import 'package:flutter/material.dart';

import '../core/app_theme.dart';
import '../data/favorites_store.dart';
import '../data/json_tools.dart';
import '../data/sports_repository.dart';
import '../widgets/app_states.dart';

class PlayerScreen extends StatefulWidget {
  final SportsRepository repository;
  final FavoritesStore favorites;
  final int athleteId;
  final String initialName;
  const PlayerScreen({super.key, required this.repository, required this.favorites, required this.athleteId, required this.initialName});

  @override
  State<PlayerScreen> createState() => _PlayerScreenState();
}

class _PlayerScreenState extends State<PlayerScreen> {
  bool loading = true;
  Object? error;
  PlayerProfileData? data;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() { loading = true; error = null; });
    try {
      final result = await widget.repository.fetchPlayerProfile(widget.athleteId);
      if (!mounted) return;
      setState(() { data = result; loading = false; });
    } catch (e) {
      if (!mounted) return;
      setState(() { error = e; loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    final player = data?.player;
    return Scaffold(
      appBar: AppBar(backgroundColor: AppColors.background, title: Text(player?.name ?? widget.initialName), actions: [IconButton(onPressed: _load, icon: const Icon(Icons.refresh_rounded))]),
      body: loading && data == null
          ? const AppLoading(text: 'جاري تحميل اللاعب...')
          : error != null && data == null
              ? AppError(error: error!, onRetry: _load)
              : ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    Container(
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(20), border: Border.all(color: AppColors.border)),
                      child: Column(children: [
                        CircleAvatar(radius: 48, backgroundColor: AppColors.surface2, backgroundImage: NetworkImage(player!.imageUrl), onBackgroundImageError: (_, __) {}),
                        const SizedBox(height: 11),
                        Text(player.name, textAlign: TextAlign.center, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
                        const SizedBox(height: 6),
                        Text([player.clubName, player.positionName].where((e) => e.isNotEmpty).join(' · '), style: const TextStyle(color: AppColors.muted, fontSize: 11)),
                      ]),
                    ),
                    const SizedBox(height: 14),
                    _Fact(title: 'النادي', value: player.clubName),
                    _Fact(title: 'الجنسية', value: player.nationalityName),
                    _Fact(title: 'المركز', value: player.positionName),
                    if (player.age > 0) _Fact(title: 'العمر', value: '${player.age} سنة'),
                    const SizedBox(height: 18),
                    const Text('بيانات إضافية', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900)),
                    const SizedBox(height: 8),
                    ..._extraFacts(data!.raw).take(12).map((e) => _Fact(title: e.key, value: e.value)),
                  ],
                ),
    );
  }

  List<MapEntry<String, String>> _extraFacts(Map<String, dynamic> raw) {
    final out = <MapEntry<String, String>>[];
    final candidate = JsonTools.findFirstByKey(raw, const {'athlete', 'player'});
    final map = JsonTools.map(candidate).isNotEmpty ? JsonTools.map(candidate) : raw;
    const labels = {
      'birthDate': 'تاريخ الميلاد',
      'height': 'الطول',
      'weight': 'الوزن',
      'shirtNumber': 'رقم القميص',
      'jerseyNumber': 'رقم القميص',
      'goals': 'الأهداف',
      'assists': 'التمريرات الحاسمة',
      'yellowCards': 'بطاقات صفراء',
      'redCards': 'بطاقات حمراء',
    };
    for (final entry in labels.entries) {
      final value = map[entry.key];
      if (value != null && '$value'.isNotEmpty && '$value' != '0' && '$value' != 'null') out.add(MapEntry(entry.value, '$value'));
    }
    return out;
  }
}

class _Fact extends StatelessWidget {
  final String title;
  final String value;
  const _Fact({required this.title, required this.value});
  @override
  Widget build(BuildContext context) {
    if (value.isEmpty) return const SizedBox.shrink();
    return Container(
      margin: const EdgeInsets.only(bottom: 7),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(13), border: Border.all(color: AppColors.border)),
      child: Row(children: [
        Text(title, style: const TextStyle(color: AppColors.muted, fontSize: 11)),
        const Spacer(),
        Flexible(child: Text(value, textAlign: TextAlign.left, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 11))),
      ]),
    );
  }
}
