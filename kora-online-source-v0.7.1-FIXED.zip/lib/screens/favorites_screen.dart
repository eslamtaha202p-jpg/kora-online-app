import 'package:flutter/material.dart';

import '../core/app_theme.dart';
import '../data/favorites_store.dart';
import '../data/sports_repository.dart';
import '../models/competition.dart';
import '../models/match.dart';
import '../models/team.dart';
import '../widgets/app_states.dart';
import '../widgets/network_logo.dart';
import 'competition_details_screen.dart';
import 'match_details_screen.dart';
import 'team_screen.dart';

class FavoritesScreen extends StatefulWidget {
  final SportsRepository repository;
  final FavoritesStore favorites;
  const FavoritesScreen({super.key, required this.repository, required this.favorites});

  @override
  State<FavoritesScreen> createState() => _FavoritesScreenState();
}

class _FavoritesScreenState extends State<FavoritesScreen> {
  @override
  void initState() {
    super.initState();
    widget.favorites.addListener(_changed);
  }

  @override
  void dispose() {
    widget.favorites.removeListener(_changed);
    super.dispose();
  }

  void _changed() { if (mounted) setState(() {}); }

  @override
  Widget build(BuildContext context) {
    final items = widget.favorites.all;
    return SafeArea(
      bottom: false,
      child: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 10),
          child: Row(children: [
            const Expanded(child: Text('المفضلة', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900))),
            if (items.isNotEmpty)
              TextButton(onPressed: () => _confirmClear(context), child: const Text('مسح الكل')),
          ]),
        ),
        Expanded(
          child: !widget.favorites.ready
              ? const AppLoading(text: 'جاري تحميل المفضلة...')
              : items.isEmpty
                  ? const EmptyState(text: 'أضف مباريات أو فرق أو بطولات للمفضلة وستظهر هنا', icon: Icons.star_border_rounded)
                  : ListView.separated(
                      padding: const EdgeInsets.fromLTRB(16, 2, 16, 24),
                      itemCount: items.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 8),
                      itemBuilder: (_, i) {
                        final item = items[i];
                        return Dismissible(
                          key: ValueKey(item.key),
                          direction: DismissDirection.endToStart,
                          onDismissed: (_) => widget.favorites.toggle(item),
                          background: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 20),
                            alignment: Alignment.centerLeft,
                            decoration: BoxDecoration(color: AppColors.danger.withValues(alpha: .18), borderRadius: BorderRadius.circular(15)),
                            child: const Icon(Icons.delete_outline_rounded, color: AppColors.danger),
                          ),
                          child: InkWell(
                            onTap: () => _open(item),
                            borderRadius: BorderRadius.circular(15),
                            child: Ink(
                              padding: const EdgeInsets.all(11),
                              decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(15), border: Border.all(color: AppColors.border)),
                              child: Row(children: [
                                NetworkLogo(url: item.imageUrl, size: 46, fallbackIcon: item.type == 'competition' ? Icons.emoji_events_outlined : Icons.star_outline_rounded),
                                const SizedBox(width: 11),
                                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                  Text(item.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w900)),
                                  const SizedBox(height: 3),
                                  Text(item.subtitle, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: AppColors.muted, fontSize: 10)),
                                ])),
                                const Icon(Icons.chevron_left_rounded, color: AppColors.muted),
                              ]),
                            ),
                          ),
                        );
                      },
                    ),
        ),
      ]),
    );
  }

  void _open(FavoriteRecord item) {
    if (item.type == 'match') {
      final match = MatchItem.fromJson(item.payload);
      Navigator.of(context).push(MaterialPageRoute(builder: (_) => MatchDetailsScreen(repository: widget.repository, favorites: widget.favorites, match: match)));
      return;
    }
    if (item.type == 'team') {
      final team = Team.fromJson(item.payload);
      Navigator.of(context).push(MaterialPageRoute(builder: (_) => TeamScreen(repository: widget.repository, favorites: widget.favorites, initialTeam: team)));
      return;
    }
    if (item.type == 'competition') {
      final competition = Competition.fromJson(item.payload);
      Navigator.of(context).push(MaterialPageRoute(builder: (_) => CompetitionDetailsScreen(repository: widget.repository, favorites: widget.favorites, competition: competition)));
    }
  }

  Future<void> _confirmClear(BuildContext context) async {
    final yes = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('مسح المفضلة؟'),
        content: const Text('سيتم حذف كل العناصر المحفوظة على هذا الجهاز.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('مسح')),
        ],
      ),
    );
    if (yes == true) await widget.favorites.clear();
  }
}
