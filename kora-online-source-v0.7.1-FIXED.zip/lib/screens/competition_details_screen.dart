import 'package:flutter/material.dart';

import '../core/app_theme.dart';
import '../data/favorites_store.dart';
import '../data/sports_repository.dart';
import '../models/competition.dart';
import '../models/match.dart';
import '../models/scorer.dart';
import '../models/standing_row.dart';
import '../widgets/app_states.dart';
import '../widgets/match_card.dart';
import '../widgets/network_logo.dart';
import 'match_details_screen.dart';
import 'player_screen.dart';
import 'team_screen.dart';

class CompetitionDetailsScreen extends StatefulWidget {
  final SportsRepository repository;
  final FavoritesStore favorites;
  final Competition competition;
  const CompetitionDetailsScreen({super.key, required this.repository, required this.favorites, required this.competition});

  @override
  State<CompetitionDetailsScreen> createState() => _CompetitionDetailsScreenState();
}

class _CompetitionDetailsScreenState extends State<CompetitionDetailsScreen> {
  bool loading = true;
  Object? error;
  List<StandingRow> standings = const [];
  List<ScorerItem> scorers = const [];
  List<MatchItem> matches = const [];

  @override
  void initState() {
    super.initState();
    widget.favorites.addListener(_favChanged);
    _load();
  }

  @override
  void dispose() {
    widget.favorites.removeListener(_favChanged);
    super.dispose();
  }

  void _favChanged() {
    if (mounted) setState(() {});
  }

  Future<void> _load() async {
    setState(() { loading = true; error = null; });
    try {
      final results = await Future.wait([
        widget.repository.fetchStandings(widget.competition.id).catchError((_) => <StandingRow>[]),
        widget.repository.fetchScorers(widget.competition.id).catchError((_) => <ScorerItem>[]),
        widget.repository.fetchCompetitionMatches(widget.competition.id).catchError((_) => <MatchItem>[]),
      ]);
      if (!mounted) return;
      setState(() {
        standings = results[0] as List<StandingRow>;
        scorers = results[1] as List<ScorerItem>;
        matches = results[2] as List<MatchItem>;
        loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() { error = e; loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    final fav = widget.favorites.contains('competition', widget.competition.id);
    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColors.background,
        title: Text(widget.competition.name, maxLines: 1, overflow: TextOverflow.ellipsis),
        actions: [
          IconButton(
            onPressed: () => widget.favorites.toggle(FavoriteRecord.competition(widget.competition)),
            icon: Icon(fav ? Icons.star_rounded : Icons.star_border_rounded, color: fav ? AppColors.accent : null),
          ),
          IconButton(onPressed: _load, icon: const Icon(Icons.refresh_rounded)),
        ],
      ),
      body: loading && standings.isEmpty && matches.isEmpty && scorers.isEmpty
          ? const AppLoading(text: 'جاري تحميل البطولة...')
          : error != null && standings.isEmpty && matches.isEmpty && scorers.isEmpty
              ? AppError(error: error!, onRetry: _load)
              : DefaultTabController(
                  length: 3,
                  child: Column(children: [
                    Padding(
                      padding: const EdgeInsets.all(16),
                      child: Row(children: [
                        NetworkLogo(url: widget.competition.logoUrl, size: 58, fallbackIcon: Icons.emoji_events_outlined),
                        const SizedBox(width: 12),
                        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(widget.competition.name, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900)),
                          const SizedBox(height: 4),
                          Text('${matches.length} مباراة · ${standings.length} فريق', style: const TextStyle(color: AppColors.muted, fontSize: 10)),
                        ])),
                      ]),
                    ),
                    const TabBar(tabs: [Tab(text: 'المباريات'), Tab(text: 'الترتيب'), Tab(text: 'الهدافون')]),
                    Expanded(
                      child: TabBarView(children: [
                        matches.isEmpty
                            ? const EmptyState(text: 'لا توجد مباريات متاحة لهذه البطولة')
                            : ListView.separated(
                                padding: const EdgeInsets.all(16),
                                itemCount: matches.length,
                                separatorBuilder: (_, __) => const SizedBox(height: 10),
                                itemBuilder: (_, i) => MatchCard(
                                  match: matches[i],
                                  compact: true,
                                  onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => MatchDetailsScreen(repository: widget.repository, favorites: widget.favorites, match: matches[i]))),
                                ),
                              ),
                        _StandingsTab(rows: standings, repository: widget.repository, favorites: widget.favorites),
                        _ScorersTab(scorers: scorers, repository: widget.repository, favorites: widget.favorites),
                      ]),
                    ),
                  ]),
                ),
    );
  }
}

class _StandingsTab extends StatelessWidget {
  final List<StandingRow> rows;
  final SportsRepository repository;
  final FavoritesStore favorites;
  const _StandingsTab({required this.rows, required this.repository, required this.favorites});

  @override
  Widget build(BuildContext context) {
    if (rows.isEmpty) return const EmptyState(text: 'جدول الترتيب غير متاح من المصدر لهذه البطولة');
    return ListView.builder(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 24),
      itemCount: rows.length + 1,
      itemBuilder: (_, i) {
        if (i == 0) {
          return const Padding(
            padding: EdgeInsets.symmetric(horizontal: 8, vertical: 8),
            child: Row(children: [
              SizedBox(width: 28, child: Text('#', style: TextStyle(color: AppColors.muted, fontSize: 10))),
              Expanded(child: Text('الفريق', style: TextStyle(color: AppColors.muted, fontSize: 10))),
              SizedBox(width: 30, child: Text('ل', textAlign: TextAlign.center, style: TextStyle(color: AppColors.muted, fontSize: 10))),
              SizedBox(width: 34, child: Text('فارق', textAlign: TextAlign.center, style: TextStyle(color: AppColors.muted, fontSize: 9))),
              SizedBox(width: 34, child: Text('ن', textAlign: TextAlign.center, style: TextStyle(color: AppColors.muted, fontSize: 10))),
            ]),
          );
        }
        final r = rows[i - 1];
        final diff = r.goalsFor - r.goalsAgainst;
        return InkWell(
          onTap: r.team.id == 0 ? null : () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => TeamScreen(repository: repository, favorites: favorites, initialTeam: r.team))),
          child: Container(
            margin: const EdgeInsets.only(bottom: 5),
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 9),
            decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.border)),
            child: Row(children: [
              SizedBox(width: 28, child: Text('${r.position == 0 ? i : r.position}', style: const TextStyle(fontWeight: FontWeight.w800))),
              NetworkLogo(url: r.team.logoUrl, size: 30),
              const SizedBox(width: 7),
              Expanded(child: Text(r.team.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 11))),
              SizedBox(width: 30, child: Text('${r.played}', textAlign: TextAlign.center, style: const TextStyle(fontSize: 10))),
              SizedBox(width: 34, child: Text('${diff > 0 ? '+' : ''}$diff', textAlign: TextAlign.center, style: const TextStyle(fontSize: 10))),
              SizedBox(width: 34, child: Text('${r.points}', textAlign: TextAlign.center, style: const TextStyle(color: AppColors.primary, fontWeight: FontWeight.w900))),
            ]),
          ),
        );
      },
    );
  }
}

class _ScorersTab extends StatelessWidget {
  final List<ScorerItem> scorers;
  final SportsRepository repository;
  final FavoritesStore favorites;
  const _ScorersTab({required this.scorers, required this.repository, required this.favorites});

  @override
  Widget build(BuildContext context) {
    if (scorers.isEmpty) return const EmptyState(text: 'قائمة الهدافين غير متاحة من المصدر');
    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: scorers.length,
      separatorBuilder: (_, __) => const SizedBox(height: 7),
      itemBuilder: (_, i) {
        final s = scorers[i];
        return InkWell(
          onTap: s.athleteId == 0 ? null : () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => PlayerScreen(repository: repository, favorites: favorites, athleteId: s.athleteId, initialName: s.name))),
          borderRadius: BorderRadius.circular(14),
          child: Ink(
            padding: const EdgeInsets.all(11),
            decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(14), border: Border.all(color: AppColors.border)),
            child: Row(children: [
              SizedBox(width: 30, child: Text('${i + 1}', style: TextStyle(fontWeight: FontWeight.w900, color: i < 3 ? AppColors.accent : AppColors.muted))),
              CircleAvatar(radius: 22, backgroundColor: AppColors.surface2, backgroundImage: NetworkImage(s.imageUrl), onBackgroundImageError: (_, __) {}),
              const SizedBox(width: 10),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(s.name, style: const TextStyle(fontWeight: FontWeight.w900)),
                if (s.teamName.isNotEmpty) Text(s.teamName, style: const TextStyle(color: AppColors.muted, fontSize: 10)),
              ])),
              Text('${s.value}', style: const TextStyle(color: AppColors.primary, fontSize: 20, fontWeight: FontWeight.w900)),
            ]),
          ),
        );
      },
    );
  }
}
