import 'package:flutter/material.dart';

import '../data/favorites_store.dart';
import '../data/settings_store.dart';
import '../data/sports_repository.dart';
import 'competitions_screen.dart';
import 'favorites_screen.dart';
import 'home_screen.dart';
import 'matches_screen.dart';
import 'more_screen.dart';

class AppShell extends StatefulWidget {
  final SportsRepository repository;
  final FavoritesStore favorites;
  final SettingsStore settings;
  const AppShell({super.key, required this.repository, required this.favorites, required this.settings});

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int index = 0;

  @override
  void initState() {
    super.initState();
    widget.favorites.load();
    widget.settings.load();
  }

  @override
  void dispose() {
    widget.repository.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final screens = [
      HomeScreen(repository: widget.repository, favorites: widget.favorites, settings: widget.settings),
      MatchesScreen(repository: widget.repository, favorites: widget.favorites, settings: widget.settings),
      CompetitionsScreen(repository: widget.repository, favorites: widget.favorites),
      FavoritesScreen(repository: widget.repository, favorites: widget.favorites),
      MoreScreen(settings: widget.settings, favorites: widget.favorites),
    ];
    return Scaffold(
      body: IndexedStack(index: index, children: screens),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (value) => setState(() => index = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home_rounded), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.sports_soccer_outlined), selectedIcon: Icon(Icons.sports_soccer_rounded), label: 'المباريات'),
          NavigationDestination(icon: Icon(Icons.emoji_events_outlined), selectedIcon: Icon(Icons.emoji_events_rounded), label: 'البطولات'),
          NavigationDestination(icon: Icon(Icons.star_border_rounded), selectedIcon: Icon(Icons.star_rounded), label: 'المفضلة'),
          NavigationDestination(icon: Icon(Icons.tune_rounded), selectedIcon: Icon(Icons.tune_rounded), label: 'الإعدادات'),
        ],
      ),
    );
  }
}
