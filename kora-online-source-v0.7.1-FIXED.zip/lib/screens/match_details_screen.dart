import 'package:flutter/material.dart';

import '../core/app_theme.dart';
import '../data/favorites_store.dart';
import '../data/json_tools.dart';
import '../data/sports_repository.dart';
import '../models/competition.dart';
import '../models/match.dart';
import '../models/prediction.dart';
import '../widgets/app_states.dart';
import '../widgets/match_card.dart';
import '../widgets/network_logo.dart';
import 'competition_details_screen.dart';
import 'team_screen.dart';

class MatchDetailsScreen extends StatefulWidget {
  final SportsRepository repository;
  final FavoritesStore favorites;
  final MatchItem match;
  const MatchDetailsScreen({super.key, required this.repository, required this.favorites, required this.match});

  @override
  State<MatchDetailsScreen> createState() => _MatchDetailsScreenState();
}

class _MatchDetailsScreenState extends State<MatchDetailsScreen> {
  bool loading = true;
  Object? error;
  MatchDetailsData? details;
  List<MatchItem> h2h = const [];
  MatchPrediction? prediction;
  int? selectedPrediction;

  @override
  void initState() {
    super.initState();
    widget.favorites.addListener(_favChanged);
    _load();
  }

  @override
  void dispose() {
    widget.favorites.removeListener(_favChanged);
    super.dispose();
  }

  void _favChanged() {
    if (mounted) setState(() {});
  }

  Future<void> _load() async {
    setState(() {
      loading = true;
      error = null;
    });
    try {
      final detailFuture = widget.repository.fetchMatchDetailsData(widget.match);
      final h2hFuture = widget.repository.fetchHeadToHead(widget.match).catchError((_) => <MatchItem>[]);
      final predictionFuture = widget.match.competitionId == 0
          ? Future<MatchPrediction?>.value(null)
          : widget.repository.fetchPrediction(widget.match.competitionId, widget.match.id).catchError((_) => null);

      final detail = await detailFuture;
      final head = await h2hFuture;
      final pred = await predictionFuture;
      if (!mounted) return;
      setState(() {
        details = detail;
        h2h = head;
        prediction = pred;
        loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        error = e;
        loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final fav = widget.favorites.contains('match', widget.match.id);
    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColors.background,
        title: const Text('تفاصيل المباراة', style: TextStyle(fontWeight: FontWeight.w900)),
        actions: [
          IconButton(
            tooltip: 'المفضلة',
            onPressed: () => widget.favorites.toggle(FavoriteRecord.match(widget.match)),
            icon: Icon(fav ? Icons.star_rounded : Icons.star_border_rounded, color: fav ? AppColors.accent : null),
          ),
          IconButton(tooltip: 'تحديث', onPressed: _load, icon: const Icon(Icons.refresh_rounded)),
        ],
      ),
      body: loading && details == null
          ? const AppLoading(text: 'جاري تحميل المباراة...')
          : error != null && details == null
              ? AppError(error: error!, onRetry: _load)
              : DefaultTabController(
                  length: 5,
                  child: Column(
                    children: [
                      _MatchHero(
                        match: widget.match,
                        onHome: () => _openTeam(widget.match.home),
                        onAway: () => _openTeam(widget.match.away),
                        onCompetition: _openCompetition,
                      ),
                      const TabBar(
                        isScrollable: true,
                        tabs: [
                          Tab(text: 'الملخص'),
                          Tab(text: 'الأحداث'),
                          Tab(text: 'التشكيل'),
                          Tab(text: 'الإحصائيات'),
                          Tab(text: 'المواجهات'),
                        ],
                      ),
                      Expanded(
                        child: TabBarView(
                          children: [
                            _SummaryTab(
                              match: widget.match,
                              info: details?.info ?? const {},
                              prediction: prediction,
                              selected: selectedPrediction,
                              onPrediction: (v) {
                                setState(() => selectedPrediction = v);
                                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم تسجيل توقعك على هذا الجهاز')));
                              },
                            ),
                            _EventsTab(events: details?.events ?? const []),
                            _LineupsTab(
                              players: details?.lineups ?? const [],
                              homeId: widget.match.home.id,
                              awayId: widget.match.away.id,
                              homeName: widget.match.home.name,
                              awayName: widget.match.away.name,
                            ),
                            _StatsTab(stats: details?.stats ?? const [], homeName: widget.match.home.name, awayName: widget.match.away.name),
                            _H2HTab(
                              matches: h2h,
                              onOpen: (m) => Navigator.of(context).push(
                                MaterialPageRoute(
                                  builder: (_) => MatchDetailsScreen(repository: widget.repository, favorites: widget.favorites, match: m),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
    );
  }

  void _openTeam(dynamic team) {
    if (team.id == 0) return;
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => TeamScreen(repository: widget.repository, favorites: widget.favorites, initialTeam: team)));
  }

  void _openCompetition() {
    if (widget.match.competitionId == 0) return;
    final competition = Competition(
      id: widget.match.competitionId,
      name: widget.match.competitionName,
      nameForUrl: '',
      imageVersion: widget.match.competitionImageVersion,
      hasStandings: widget.match.hasStandings,
    );
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => CompetitionDetailsScreen(repository: widget.repository, favorites: widget.favorites, competition: competition),
      ),
    );
  }
}

class _MatchHero extends StatelessWidget {
  final MatchItem match;
  final VoidCallback onHome;
  final VoidCallback onAway;
  final VoidCallback onCompetition;
  const _MatchHero({required this.match, required this.onHome, required this.onAway, required this.onCompetition});

  @override
  Widget build(BuildContext context) {
    final hasScore = match.home.score != null && match.away.score != null;
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 6, 16, 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xFF102D50), Color(0xFF0B182A)]),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFF195F90)),
      ),
      child: Column(
        children: [
          InkWell(
            onTap: onCompetition,
            borderRadius: BorderRadius.circular(10),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.emoji_events_outlined, size: 15, color: AppColors.primary),
                  const SizedBox(width: 6),
                  Flexible(
                    child: Text(
                      match.competitionName,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(color: AppColors.primary, fontWeight: FontWeight.w800, fontSize: 11),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              Expanded(child: _TeamButton(name: match.home.name, logo: match.home.logoUrl, onTap: onHome)),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                child: Column(
                  children: [
                    Text(
                      hasScore ? '${match.home.score}  -  ${match.away.score}' : match.kickoffLabel,
                      style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w900),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      match.isLive ? (match.gameTimeDisplay.isNotEmpty ? match.gameTimeDisplay : '${match.gameTime}\'') : match.statusText,
                      style: TextStyle(color: match.isLive ? AppColors.success : AppColors.muted, fontSize: 11, fontWeight: FontWeight.w700),
                    ),
                  ],
                ),
              ),
              Expanded(child: _TeamButton(name: match.away.name, logo: match.away.logoUrl, onTap: onAway)),
            ],
          ),
          if (match.venueName.isNotEmpty || match.aggregateText.isNotEmpty) ...[
            const SizedBox(height: 14),
            const Divider(height: 1),
            const SizedBox(height: 10),
            Text(
              [match.venueName, match.aggregateText].where((e) => e.isNotEmpty).join(' · '),
              textAlign: TextAlign.center,
              style: const TextStyle(color: AppColors.muted, fontSize: 10),
            ),
          ],
        ],
      ),
    );
  }
}

class _TeamButton extends StatelessWidget {
  final String name;
  final String logo;
  final VoidCallback onTap;
  const _TeamButton({required this.name, required this.logo, required this.onTap});

  @override
  Widget build(BuildContext context) => InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: Padding(
          padding: const EdgeInsets.all(5),
          child: Column(
            children: [
              NetworkLogo(url: logo, size: 54),
              const SizedBox(height: 8),
              Text(name, maxLines: 2, textAlign: TextAlign.center, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w900)),
            ],
          ),
        ),
      );
}

class _SummaryTab extends StatelessWidget {
  final MatchItem match;
  final Map<String, String> info;
  final MatchPrediction? prediction;
  final int? selected;
  final ValueChanged<int> onPrediction;
  const _SummaryTab({required this.match, required this.info, required this.prediction, required this.selected, required this.onPrediction});

  @override
  Widget build(BuildContext context) {
    final entries = <MapEntry<String, String>>[];
    if (match.roundName.isNotEmpty) entries.add(MapEntry('الجولة', match.roundName));
    if (match.stageName.isNotEmpty) entries.add(MapEntry('المرحلة', match.stageName));
    if (match.venueName.isNotEmpty) entries.add(MapEntry('الملعب', match.venueName));
    for (final e in info.entries) {
      if (!entries.any((x) => x.key == e.key) && e.value.isNotEmpty) entries.add(e);
    }

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        if (entries.isNotEmpty)
          _Card(
            child: Column(
              children: entries
                  .map(
                    (e) => Padding(
                      padding: const EdgeInsets.symmetric(vertical: 7),
                      child: Row(
                        children: [
                          Text(e.key, style: const TextStyle(color: AppColors.muted, fontSize: 11)),
                          const Spacer(),
                          Flexible(child: Text(e.value, textAlign: TextAlign.left, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 11))),
                        ],
                      ),
                    ),
                  )
                  .toList(),
            ),
          ),
        if (prediction != null) ...[
          const SizedBox(height: 12),
          _Card(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(prediction!.title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15)),
                if (prediction!.totalVotes > 0) ...[
                  const SizedBox(height: 4),
                  Text('${prediction!.totalVotes} صوت', style: const TextStyle(color: AppColors.muted, fontSize: 10)),
                ],
                const SizedBox(height: 12),
                ...prediction!.options.map(
                  (o) => Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: InkWell(
                      onTap: () => onPrediction(o.number),
                      borderRadius: BorderRadius.circular(12),
                      child: Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: selected == o.number ? const Color(0x2414B8FF) : AppColors.surface2,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: selected == o.number ? AppColors.primary : AppColors.border),
                        ),
                        child: Row(
                          children: [
                            Expanded(child: Text(o.name, style: const TextStyle(fontWeight: FontWeight.w800))),
                            Text('${o.percentage}%', style: const TextStyle(color: AppColors.primary, fontWeight: FontWeight.w900)),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
        const SizedBox(height: 12),
        _Card(
          child: Column(
            children: [
              _AvailabilityRow(icon: Icons.timeline_rounded, title: 'الأحداث', available: match.isLive || match.isFinished),
              const Divider(height: 18),
              _AvailabilityRow(icon: Icons.groups_rounded, title: 'التشكيل', available: match.hasLineups),
              const Divider(height: 18),
              _AvailabilityRow(icon: Icons.bar_chart_rounded, title: 'الإحصائيات', available: match.hasStats),
              const Divider(height: 18),
              _AvailabilityRow(icon: Icons.compare_arrows_rounded, title: 'المواجهات السابقة', available: match.hasPreviousMeetings),
            ],
          ),
        ),
      ],
    );
  }
}

class _AvailabilityRow extends StatelessWidget {
  final IconData icon;
  final String title;
  final bool available;
  const _AvailabilityRow({required this.icon, required this.title, required this.available});

  @override
  Widget build(BuildContext context) => Row(
        children: [
          Icon(icon, size: 18, color: available ? AppColors.success : AppColors.muted),
          const SizedBox(width: 9),
          Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 11))),
          Text(available ? 'متاح' : 'غير متاح', style: TextStyle(color: available ? AppColors.success : AppColors.muted, fontSize: 10)),
        ],
      );
}

class _EventsTab extends StatelessWidget {
  final List<Map<String, dynamic>> events;
  const _EventsTab({required this.events});

  @override
  Widget build(BuildContext context) {
    if (events.isEmpty) return const EmptyState(text: 'المصدر لم يُرجع أحداثًا لهذه المباراة');
    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: events.length,
      separatorBuilder: (_, __) => const SizedBox(height: 7),
      itemBuilder: (_, i) {
        final e = events[i];
        final minute = JsonTools.firstText(e, const ['gameTimeDisplay', 'minute', 'gameTime', 'time']);
        final athlete = JsonTools.firstText(e, const ['athleteName', 'playerName', 'athlete', 'player']);
        final type = JsonTools.firstText(e, const ['eventName', 'eventText', 'eventType', 'type', 'name', 'title']);
        final lower = type.toLowerCase();
        IconData icon = Icons.circle;
        Color color = AppColors.muted;
        if (lower.contains('goal') || type.contains('هدف')) {
          icon = Icons.sports_soccer_rounded;
          color = AppColors.success;
        } else if (lower.contains('yellow') || type.contains('صفر')) {
          icon = Icons.style_rounded;
          color = AppColors.accent;
        } else if (lower.contains('red') || type.contains('حمر')) {
          icon = Icons.style_rounded;
          color = AppColors.danger;
        } else if (lower.contains('sub') || type.contains('تبديل')) {
          icon = Icons.swap_vert_rounded;
          color = AppColors.primary;
        }

        return _Card(
          child: Row(
            children: [
              SizedBox(width: 42, child: Text(minute.isEmpty ? '•' : (minute.contains("'") ? minute : "$minute'"), style: const TextStyle(color: AppColors.primary, fontWeight: FontWeight.w900))),
              Icon(icon, size: 19, color: color),
              const SizedBox(width: 9),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(type.isEmpty ? 'حدث في المباراة' : type, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 11)),
                    if (athlete.isNotEmpty) Text(athlete, style: const TextStyle(color: AppColors.muted, fontSize: 10)),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class _LineupsTab extends StatelessWidget {
  final List<Map<String, dynamic>> players;
  final int homeId;
  final int awayId;
  final String homeName;
  final String awayName;
  const _LineupsTab({required this.players, required this.homeId, required this.awayId, required this.homeName, required this.awayName});

  @override
  Widget build(BuildContext context) {
    if (players.isEmpty) return const EmptyState(text: 'المصدر لم يُرجع التشكيل لهذه المباراة');
    final home = players.where((p) => JsonTools.intValue(p['competitorId']) == homeId).toList(growable: false);
    final away = players.where((p) => JsonTools.intValue(p['competitorId']) == awayId).toList(growable: false);
    final unknown = players.where((p) {
      final id = JsonTools.intValue(p['competitorId']);
      return id == 0 || (id != homeId && id != awayId);
    }).toList(growable: false);

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        if (home.isNotEmpty) ...[
          _SectionTitle(homeName),
          ...home.map((p) => _PlayerRow(player: p)),
          const SizedBox(height: 14),
        ],
        if (away.isNotEmpty) ...[
          _SectionTitle(awayName),
          ...away.map((p) => _PlayerRow(player: p)),
          const SizedBox(height: 14),
        ],
        if (unknown.isNotEmpty) ...[
          if (home.isNotEmpty || away.isNotEmpty) const _SectionTitle('باقي القائمة'),
          ...unknown.map((p) => _PlayerRow(player: p)),
        ],
      ],
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String title;
  const _SectionTitle(this.title);
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: Text(title, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w900)),
      );
}

class _PlayerRow extends StatelessWidget {
  final Map<String, dynamic> player;
  const _PlayerRow({required this.player});

  @override
  Widget build(BuildContext context) {
    final athlete = JsonTools.map(player['athlete'] ?? player['player']);
    final name = (player['name'] ?? athlete['name'] ?? player['athleteName'] ?? player['playerName'] ?? 'لاعب').toString();
    final number = (player['jerseyNumber'] ?? athlete['jerseyNumber'] ?? '').toString();
    final pos = JsonTools.firstText(player, const ['positionName', 'formationPosition', 'position']);
    final starter = player['isStarter'] != false;
    return Container(
      margin: const EdgeInsets.only(bottom: 7),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(13), border: Border.all(color: AppColors.border)),
      child: Row(
        children: [
          CircleAvatar(
            radius: 19,
            backgroundColor: AppColors.surface2,
            child: Text(number.isEmpty ? '•' : number, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w900)),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(name, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 11)),
                if (pos.isNotEmpty) Text(pos, style: const TextStyle(color: AppColors.muted, fontSize: 9)),
              ],
            ),
          ),
          Text(starter ? 'أساسي' : 'بديل', style: TextStyle(color: starter ? AppColors.success : AppColors.muted, fontSize: 9, fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }
}

class _StatsTab extends StatelessWidget {
  final List<Map<String, dynamic>> stats;
  final String homeName;
  final String awayName;
  const _StatsTab({required this.stats, required this.homeName, required this.awayName});

  @override
  Widget build(BuildContext context) {
    if (stats.isEmpty) return const EmptyState(text: 'المصدر لم يُرجع إحصائيات لهذه المباراة');
    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: stats.length + 1,
      separatorBuilder: (_, __) => const SizedBox(height: 7),
      itemBuilder: (_, i) {
        if (i == 0) {
          return Padding(
            padding: const EdgeInsets.only(bottom: 4),
            child: Row(
              children: [
                SizedBox(width: 70, child: Text(homeName, maxLines: 1, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: const TextStyle(fontSize: 9, color: AppColors.muted))),
                const Expanded(child: Text('الإحصائيات', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w900))),
                SizedBox(width: 70, child: Text(awayName, maxLines: 1, overflow: TextOverflow.ellipsis, textAlign: TextAlign.center, style: const TextStyle(fontSize: 9, color: AppColors.muted))),
              ],
            ),
          );
        }
        final s = stats[i - 1];
        final name = JsonTools.firstText(s, const ['name', 'title', 'statName']);
        final home = JsonTools.firstText(s, const ['home', 'homeValue', 'homeCompetitorValue', 'value1']);
        final away = JsonTools.firstText(s, const ['away', 'awayValue', 'awayCompetitorValue', 'value2']);
        return _Card(
          child: Row(
            children: [
              SizedBox(width: 55, child: Text(home.isEmpty ? '—' : home, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w900))),
              Expanded(child: Text(name.isEmpty ? 'إحصائية' : name, textAlign: TextAlign.center, style: const TextStyle(color: AppColors.muted, fontSize: 11))),
              SizedBox(width: 55, child: Text(away.isEmpty ? '—' : away, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w900))),
            ],
          ),
        );
      },
    );
  }
}

class _H2HTab extends StatelessWidget {
  final List<MatchItem> matches;
  final ValueChanged<MatchItem> onOpen;
  const _H2HTab({required this.matches, required this.onOpen});

  @override
  Widget build(BuildContext context) {
    if (matches.isEmpty) return const EmptyState(text: 'لا توجد مواجهات سابقة مرجعة من المصدر');
    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: matches.length,
      separatorBuilder: (_, __) => const SizedBox(height: 9),
      itemBuilder: (_, i) => MatchCard(match: matches[i], compact: true, onTap: () => onOpen(matches[i])),
    );
  }
}

class _Card extends StatelessWidget {
  final Widget child;
  const _Card({required this.child});

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(13),
        decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(15), border: Border.all(color: AppColors.border)),
        child: child,
      );
}
