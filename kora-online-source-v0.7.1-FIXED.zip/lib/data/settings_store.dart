import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SettingsStore extends ChangeNotifier {
  static const _compactKey = 'setting_compact_cards';
  static const _liveFirstKey = 'setting_live_first';
  static const _autoRefreshKey = 'setting_auto_refresh';
  static const _refreshSecondsKey = 'setting_refresh_seconds';

  bool compactCards = false;
  bool liveFirst = true;
  bool autoRefresh = true;
  int refreshSeconds = 60;
  bool ready = false;

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    compactCards = prefs.getBool(_compactKey) ?? false;
    liveFirst = prefs.getBool(_liveFirstKey) ?? true;
    autoRefresh = prefs.getBool(_autoRefreshKey) ?? true;
    refreshSeconds = prefs.getInt(_refreshSecondsKey) ?? 60;
    if (![30, 60, 120].contains(refreshSeconds)) refreshSeconds = 60;
    ready = true;
    notifyListeners();
  }

  Future<void> setCompactCards(bool value) async {
    compactCards = value;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_compactKey, value);
  }

  Future<void> setLiveFirst(bool value) async {
    liveFirst = value;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_liveFirstKey, value);
  }

  Future<void> setAutoRefresh(bool value) async {
    autoRefresh = value;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_autoRefreshKey, value);
  }

  Future<void> setRefreshSeconds(int value) async {
    refreshSeconds = value;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_refreshSecondsKey, value);
  }

  Future<void> reset() async {
    compactCards = false;
    liveFirst = true;
    autoRefresh = true;
    refreshSeconds = 60;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_compactKey);
    await prefs.remove(_liveFirstKey);
    await prefs.remove(_autoRefreshKey);
    await prefs.remove(_refreshSecondsKey);
  }
}
