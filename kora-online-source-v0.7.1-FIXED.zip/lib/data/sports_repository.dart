import 'dart:convert';

import 'package:http/http.dart' as http;

import '../core/api_config.dart';
import '../models/competition.dart';
import '../models/match.dart';
import '../models/player.dart';
import '../models/prediction.dart';
import '../models/scorer.dart';
import '../models/standing_row.dart';
import '../models/team.dart';
import 'json_tools.dart';

class SportsRepository {
  final http.Client _client;

  SportsRepository({http.Client? client}) : _client = client ?? http.Client();

  Future<List<MatchItem>> fetchMatchesForDate(DateTime date) async {
    final d = _date(date);
    final json = await _get('/web/games/all/', {'startDate': d, 'endDate': d});
    return parseMatches(json);
  }

  Future<List<MatchItem>> fetchLiveMatches() async {
    final json = await _get('/web/games/current/');
    final all = parseMatches(json);
    final live = all.where((m) => m.isLive).toList(growable: false);
    return live.isNotEmpty ? live : all.where((m) => m.statusGroup == 3).toList(growable: false);
  }

  Future<List<Competition>> fetchTopCompetitions({int limit = 50}) async {
    final out = <Competition>[];
    final seen = <int>{};

    Future<void> addFrom(Future<Map<String, dynamic>> task) async {
      try {
        final json = await task;
        for (final c in _competitions(json)) {
          if (c.id != 0 && seen.add(c.id)) out.add(c);
        }
      } catch (_) {}
    }

    await addFrom(_get('/web/competitions/top/', {'limit': '$limit', 'sports': '1'}));
    await addFrom(_get('/web/competitions/', {'withSeasons': 'true', 'sports': '1'}));

    return out.take(limit).toList(growable: false);
  }

  /// Catalog used by the competitions tab. The public web service does not
  /// expose one stable "all competitions" payload in every context, so we
  /// merge the catalog response, top competitions, and competitions actually
  /// active around today. This avoids the old top-10-only behavior.
  Future<List<Competition>> fetchCompetitionsCatalog({DateTime? around}) async {
    final day = around ?? DateTime.now();
    final responses = await Future.wait<Map<String, dynamic>?>([
      _get('/web/competitions/top/', {'limit': '200', 'sports': '1'}).then<Map<String, dynamic>?>((v) => v).catchError((_) => null),
      _get('/web/competitions/', {'withSeasons': 'true', 'sports': '1'}).then<Map<String, dynamic>?>((v) => v).catchError((_) => null),
      _get('/web/games/all/', {'startDate': _date(day.subtract(const Duration(days: 2))), 'endDate': _date(day.add(const Duration(days: 4)))})
          .then<Map<String, dynamic>?>((v) => v)
          .catchError((_) => null),
    ]);

    final byId = <int, Competition>{};
    for (final json in responses.whereType<Map<String, dynamic>>()) {
      for (final c in _competitions(json)) {
        if (c.id != 0) byId[c.id] = c;
      }
      for (final m in parseMatches(json)) {
        if (m.competitionId == 0) continue;
        byId.putIfAbsent(
          m.competitionId,
          () => Competition(
            id: m.competitionId,
            name: m.competitionName,
            nameForUrl: '',
            imageVersion: m.competitionImageVersion,
            hasStandings: m.hasStandings,
          ),
        );
      }
    }

    final list = byId.values.toList();
    list.sort((a, b) {
      if (a.hasStandings != b.hasStandings) return a.hasStandings ? -1 : 1;
      return a.name.compareTo(b.name);
    });
    return list;
  }

  Future<List<MatchItem>> fetchCompetitionMatches(int competitionId) async {
    var json = await _get('/web/games/all/', {'competitions': '$competitionId'});
    var matches = parseMatches(json).where((m) => m.competitionId == 0 || m.competitionId == competitionId).toList(growable: false);
    if (matches.isNotEmpty) return matches;

    final now = DateTime.now();
    json = await _get('/web/games/all/', {
      'competitions': '$competitionId',
      'startDate': _date(now.subtract(const Duration(days: 45))),
      'endDate': _date(now.add(const Duration(days: 75))),
    });
    matches = parseMatches(json).where((m) => m.competitionId == 0 || m.competitionId == competitionId).toList(growable: false);
    matches.sort((a, b) {
      final x = a.startTime?.millisecondsSinceEpoch ?? 0;
      final y = b.startTime?.millisecondsSinceEpoch ?? 0;
      return x.compareTo(y);
    });
    return matches;
  }

  Future<List<StandingRow>> fetchStandings(int competitionId) async {
    final json = await _get('/web/standings/', {
      'competitions': '$competitionId',
    });

    final blocks = JsonTools.list(json['standings']);
    if (blocks.isEmpty) return const [];

    final matching = blocks.where((b) {
      final id = JsonTools.intValue(b['competitionId'] ?? b['competition'] ?? JsonTools.map(b['competition'])['id']);
      return id == 0 || id == competitionId;
    }).toList(growable: false);

    final pool = matching.isNotEmpty ? matching : (blocks.length == 1 ? blocks : const <Map<String, dynamic>>[]);
    if (pool.isEmpty) return const [];

    final out = <StandingRow>[];
    final seen = <int>{};

    for (final block in pool) {
      var rows = JsonTools.list(block['rows']);
      if (rows.isEmpty) {
        for (final group in JsonTools.list(block['groups'])) {
          rows = [...rows, ...JsonTools.list(group['rows'])];
        }
      }
      for (final raw in rows) {
        final row = StandingRow.fromJson(raw);
        if (row.team.id != 0 && seen.add(row.team.id)) out.add(row);
      }
    }

    out.sort((a, b) {
      if (a.position != 0 && b.position != 0) return a.position.compareTo(b.position);
      return b.points.compareTo(a.points);
    });
    return out;
  }

  Future<List<ScorerItem>> fetchScorers(int competitionId) async {
    final json = await _get('/web/stats/', {
      'competitions': '$competitionId',
      'competitors': '',
      'withSeasons': 'true',
    });

    final stats = JsonTools.map(json['stats']);
    final blocks = JsonTools.list(stats['athletesStats']);

    // Never fall back to another competition. This was the reason the same
    // scorers appeared in every league in the previous build.
    final matching = blocks.where((b) => JsonTools.intValue(b['competitionId']) == competitionId).toList(growable: false);
    if (matching.isEmpty) return const [];

    Map<String, dynamic>? goals;
    for (final block in matching) {
      final id = JsonTools.intValue(block['id']);
      final name = '${block['name'] ?? ''}'.toLowerCase();
      if (id == 1 || name == 'goals' || name.contains('هدف') || name.contains('goal')) {
        goals = block;
        break;
      }
    }
    if (goals == null) return const [];

    final competitors = _competitorNames(json);
    final statTypes = JsonTools.list(goals['statsTypes']);
    Map<String, dynamic>? goalType;
    for (final t in statTypes) {
      if (JsonTools.intValue(t['typeId']) == 1) {
        goalType = t;
        break;
      }
    }
    goalType ??= statTypes.isNotEmpty ? statTypes.first : const <String, dynamic>{};

    final seen = <int>{};
    final out = JsonTools.list(goals['rows'])
        .map((row) => ScorerItem.fromRow(row, competitorNames: competitors, statType: goalType))
        .where((s) => s.athleteId != 0 && seen.add(s.athleteId))
        .toList(growable: false);

    out.sort((a, b) => b.value.compareTo(a.value));
    return out;
  }

  Future<MatchPrediction?> fetchPrediction(int competitionId, int gameId) async {
    final json = await _get('/web/games/predictions/', {'competitions': '$competitionId'});
    for (final game in _gameMaps(json)) {
      final prediction = MatchPrediction.fromGameJson(game);
      if (prediction != null && prediction.gameId == gameId) return prediction;
    }

    final promoted = JsonTools.findBestList(
      json,
      looksLike: (m) => m.containsKey('gameId') && (m.containsKey('options') || m.containsKey('question') || m.containsKey('prediction')),
    );
    for (final game in promoted) {
      final prediction = MatchPrediction.fromGameJson(game);
      if (prediction != null && prediction.gameId == gameId) return prediction;
    }
    return null;
  }

  Future<Map<String, dynamic>> fetchMatchDetails(MatchItem match) => _get('/web/game/', {
        'gameId': '${match.id}',
        'matchupId': match.matchupId,
        'topBookmaker': '14',
      });

  Future<Map<String, dynamic>> fetchMatchStats(MatchItem match) => _get('/web/game/stats/', {
        'games': '${match.id}',
      });

  Future<MatchDetailsData> fetchMatchDetailsData(MatchItem match) async {
    final raw = await fetchMatchDetails(match);
    final directGame = JsonTools.map(raw['game']);
    final game = directGame.isNotEmpty ? directGame : _findGame(raw, match.id);

    Map<String, dynamic> statsRaw = const {};
    if (match.hasStats || match.isLive || match.isFinished) {
      try {
        statsRaw = await fetchMatchStats(match);
      } catch (_) {
        statsRaw = const {};
      }
    }

    return MatchDetailsData(
      raw: raw,
      game: game,
      events: _eventsFromGame(raw, game),
      lineups: _lineupsFromGame(raw, game, match),
      stats: _statsForTeams(statsRaw, game, match.home.id, match.away.id),
      info: _matchInfoFromGame(game),
    );
  }

  Future<List<MatchItem>> fetchHeadToHead(MatchItem match) async {
    Map<String, dynamic> json = const {};
    try {
      json = await _get('/web/h2h/', {
        'gameId': '${match.id}',
        'matchupId': match.matchupId,
      });
    } catch (_) {
      // Some game-center payloads expose h2h data inside the game response.
      try {
        json = await fetchMatchDetails(match);
      } catch (_) {
        return const [];
      }
    }

    final game = JsonTools.map(json['game']);
    var rows = JsonTools.list(game['h2hGames']);
    if (rows.isEmpty) rows = JsonTools.list(json['h2hGames']);
    if (rows.isEmpty) {
      final parsed = parseMatches(json);
      final seen = <int>{};
      return parsed.where((m) => m.id != 0 && m.id != match.id && seen.add(m.id)).toList(growable: false);
    }

    final seen = <int>{};
    return rows
        .map(MatchItem.fromJson)
        .where((m) => m.id != 0 && m.id != match.id && seen.add(m.id))
        .toList(growable: false);
  }

  Future<TeamProfileData> fetchTeamProfile(int teamId) async {
    final json = await _get('/web/teams/', {'team': '$teamId'});
    final teamMap = _findEntity(json, id: teamId, keys: const {'teams', 'competitors', 'team', 'competitor'});
    final team = Team.fromJson(teamMap.isEmpty ? {'id': teamId, 'name': 'الفريق'} : teamMap);

    final competitorNames = _competitorNames(json);
    final directAthletes = JsonTools.list(json['athletes']);
    var playerMaps = directAthletes;
    if (playerMaps.isEmpty) {
      playerMaps = JsonTools.findBestList(
        json,
        looksLike: (m) => (m.containsKey('athlete') || m.containsKey('athleteId') || m.containsKey('positionName')) &&
            (m.containsKey('id') || m.containsKey('athleteId') || m.containsKey('athlete')),
      );
    }

    final seen = <int>{};
    final players = playerMaps.map((p) {
      final normalized = Map<String, dynamic>.from(p);
      final athlete = JsonTools.map(normalized['athlete']);
      final clubId = JsonTools.intValue(athlete['clubId'] ?? normalized['clubId'] ?? athlete['competitorId']);
      if ((athlete['clubName'] == null || '${athlete['clubName']}'.isEmpty) && clubId != 0 && competitorNames[clubId] != null) {
        if (athlete.isNotEmpty) normalized['athlete'] = {...athlete, 'clubName': competitorNames[clubId]};
      }
      return PlayerItem.fromJson(normalized);
    }).where((p) => p.id != 0 && seen.add(p.id)).toList(growable: false);

    final matches = parseMatches(json);
    return TeamProfileData(team: team, players: players, matches: matches, raw: json);
  }

  Future<PlayerProfileData> fetchPlayerProfile(int athleteId) async {
    final json = await _get('/web/athletes/', {'athlete': '$athleteId'});
    var athleteMap = _findEntity(json, id: athleteId, keys: const {'athletes', 'athlete', 'players', 'player'});
    if (athleteMap.isEmpty) {
      final athletes = JsonTools.list(json['athletes']);
      if (athletes.isNotEmpty) athleteMap = athletes.first;
    }
    final player = PlayerItem.fromJson(athleteMap.isEmpty ? {'id': athleteId, 'name': 'اللاعب'} : athleteMap);
    return PlayerProfileData(player: player, raw: json);
  }

  List<MatchItem> parseMatches(Map<String, dynamic> json) {
    final seen = <int>{};
    final out = <MatchItem>[];
    for (final raw in _gameMaps(json)) {
      final m = MatchItem.fromJson(raw);
      if (m.id != 0 && seen.add(m.id)) out.add(m);
    }
    return out;
  }

  Map<int, Map<String, dynamic>> _memberLookup(Map<String, dynamic> raw, Map<String, dynamic> game) {
    final out = <int, Map<String, dynamic>>{};
    final members = <Map<String, dynamic>>[
      ...JsonTools.list(raw['members']),
      ...JsonTools.list(game['members']),
    ];
    for (final member in members) {
      final id = JsonTools.intValue(member['id']);
      final athleteId = JsonTools.intValue(member['athleteId']);
      if (id != 0) out[id] = member;
      if (athleteId != 0) out[athleteId] = member;
    }
    return out;
  }

  List<Map<String, dynamic>> _eventsFromGame(Map<String, dynamic> raw, Map<String, dynamic> game) {
    final members = _memberLookup(raw, game);
    final events = JsonTools.list(game['events']);
    final out = <Map<String, dynamic>>[];

    for (final event in events) {
      final playerId = JsonTools.intValue(event['playerId'] ?? event['athleteId']);
      final player = members[playerId] ?? const <String, dynamic>{};
      final eventType = JsonTools.map(event['eventType']);
      final added = JsonTools.intValue(event['addedTime']);
      final minuteBase = event['gameTimeDisplay']?.toString().trim();
      final minute = (minuteBase != null && minuteBase.isNotEmpty)
          ? minuteBase
          : (JsonTools.intValue(event['gameTime']) == 0
              ? ''
              : "${JsonTools.intValue(event['gameTime'])}${added > 0 ? '+$added' : ''}");

      final extras = <String>[];
      for (final idValue in event['extraPlayers'] is List ? event['extraPlayers'] as List : const []) {
        final extra = members[JsonTools.intValue(idValue)];
        final name = '${extra?['name'] ?? extra?['shortName'] ?? ''}'.trim();
        if (name.isNotEmpty) extras.add(name);
      }

      out.add({
        ...event,
        'minute': minute,
        'gameTimeDisplay': minute,
        'athleteId': player['athleteId'] ?? playerId,
        'athleteName': player['name'] ?? player['shortName'] ?? '',
        'eventName': eventType['name'] ?? eventType['subTypeName'] ?? event['eventName'] ?? '',
        'extraPlayerNames': extras,
      });
    }

    out.sort((a, b) {
      final ao = JsonTools.intValue(a['order']);
      final bo = JsonTools.intValue(b['order']);
      if (ao != 0 || bo != 0) return ao.compareTo(bo);
      return JsonTools.intValue(a['gameTime']).compareTo(JsonTools.intValue(b['gameTime']));
    });
    return out;
  }

  List<Map<String, dynamic>> _lineupsFromGame(
    Map<String, dynamic> raw,
    Map<String, dynamic> game,
    MatchItem match,
  ) {
    final members = _memberLookup(raw, game);
    final out = <Map<String, dynamic>>[];

    void addTeam(Map<String, dynamic> competitor, int competitorId) {
      final lineups = JsonTools.map(competitor['lineups']);
      final lineupMembers = JsonTools.list(lineups['members']);

      for (final slot in lineupMembers) {
        final id = JsonTools.intValue(slot['id']);
        final athleteId = JsonTools.intValue(slot['athleteId']);
        final master = members[id] ?? members[athleteId] ?? const <String, dynamic>{};
        final merged = <String, dynamic>{...master, ...slot};
        final status = JsonTools.intValue(merged['status']);

        out.add({
          ...merged,
          'athlete': merged,
          'athleteId': merged['athleteId'] ?? merged['id'],
          'name': merged['name'] ?? merged['shortName'] ?? 'لاعب',
          'competitorId': competitorId,
          'jerseyNumber': merged['jerseyNumber'] ?? '',
          'positionName': merged['positionName'] ??
              JsonTools.map(merged['position'])['name'] ??
              '',
          'isStarter': status == 0 ? true : status == 1,
          'lineupStatus': status,
          'formation': lineups['formation'] ?? '',
        });
      }
    }

    addTeam(JsonTools.map(game['homeCompetitor']), match.home.id);
    addTeam(JsonTools.map(game['awayCompetitor']), match.away.id);

    return _dedupeLineup(out);
  }

  List<Map<String, dynamic>> _statsForTeams(
    Map<String, dynamic> statsRaw,
    Map<String, dynamic> game,
    int homeId,
    int awayId,
  ) {
    final rows = JsonTools.list(statsRaw['statistics']);
    final grouped = <String, Map<String, dynamic>>{};

    for (final stat in rows) {
      final name = '${stat['name'] ?? stat['shortName'] ?? stat['displayName'] ?? ''}'.trim();
      if (name.isEmpty) continue;
      final id = JsonTools.intValue(stat['id']);
      final category = '${stat['categoryName'] ?? ''}';
      final key = '${id == 0 ? name : id}|$category';
      final row = grouped.putIfAbsent(key, () => {
            'name': name,
            'home': '',
            'away': '',
            'order': JsonTools.intValue(stat['order']),
            'categoryName': category,
          });
      final competitorId = JsonTools.intValue(stat['competitorId']);
      final value = stat['value'] ?? stat['displayValue'] ?? '';
      if (competitorId == homeId) row['home'] = '$value';
      if (competitorId == awayId) row['away'] = '$value';
    }

    // /web/game/ also exposes a statistics array on each competitor in many
    // matches. Use it as a direct fallback when /web/game/stats/ is empty.
    if (grouped.isEmpty) {
      final home = JsonTools.map(game['homeCompetitor']);
      final away = JsonTools.map(game['awayCompetitor']);

      void addSide(List<Map<String, dynamic>> stats, bool isHome) {
        for (final stat in stats) {
          final name = '${stat['name'] ?? stat['shortName'] ?? ''}'.trim();
          if (name.isEmpty) continue;
          final id = JsonTools.intValue(stat['id'] ?? stat['type']);
          final key = '${id == 0 ? name : id}|${stat['categoryName'] ?? ''}';
          final row = grouped.putIfAbsent(key, () => {
                'name': name,
                'home': '',
                'away': '',
                'order': JsonTools.intValue(stat['order']),
              });
          final value = stat['value'] ?? '';
          row[isHome ? 'home' : 'away'] = '$value';
        }
      }

      addSide(JsonTools.list(home['statistics']), true);
      addSide(JsonTools.list(away['statistics']), false);
    }

    final result = grouped.values
        .where((r) => '${r['home']}'.isNotEmpty || '${r['away']}'.isNotEmpty)
        .toList(growable: false);
    result.sort((a, b) => JsonTools.intValue(a['order']).compareTo(JsonTools.intValue(b['order'])));
    return result;
  }

  Map<String, String> _matchInfoFromGame(Map<String, dynamic> game) {
    final info = <String, String>{};
    final venue = JsonTools.map(game['venue']);
    final officials = JsonTools.list(game['officials']);

    void put(String key, dynamic value) {
      final text = value == null ? '' : '$value'.trim();
      if (text.isNotEmpty && text != 'null' && text != '0') info[key] = text;
    }

    put('الملعب', venue['name'] ?? game['venueName']);
    if (officials.isNotEmpty) put('الحكم', officials.first['name']);
    put('الجولة', game['roundName']);
    put('المرحلة', game['stageName']);
    put('الحضور', venue['attendance'] ?? game['attendance']);
    put('الحالة', game['statusText']);
    return info;
  }

  List<Map<String, dynamic>> extractEvents(Map<String, dynamic> json) {
    final out = <Map<String, dynamic>>[];

    void walk(dynamic value, String path, int depth) {
      if (depth > 12) return;
      if (value is List) {
        final list = JsonTools.list(value);
        final eventPath = path.contains('event') || path.contains('incident') || path.contains('timeline') || path.contains('playbyplay');
        for (final item in list) {
          if ((eventPath && _looksLikeEvent(item)) || _looksLikeEvent(item)) out.add(_normalizeEvent(item));
        }
        for (final child in value) {
          walk(child, path, depth + 1);
        }
      } else if (value is Map) {
        final map = JsonTools.map(value);
        if (_looksLikeEvent(map) && (path.contains('event') || path.contains('incident') || map.containsKey('eventTypeId'))) {
          out.add(_normalizeEvent(map));
        }
        for (final entry in value.entries) {
          walk(entry.value, '$path/${entry.key}'.toLowerCase(), depth + 1);
        }
      }
    }

    walk(json, '', 0);
    final deduped = _dedupeMaps(out);
    deduped.sort((a, b) {
      final x = JsonTools.intValue(a['gameTime'] ?? a['minute'] ?? a['time']);
      final y = JsonTools.intValue(b['gameTime'] ?? b['minute'] ?? b['time']);
      return y.compareTo(x);
    });
    return deduped;
  }

  List<Map<String, dynamic>> extractLineupPlayers(Map<String, dynamic> json) {
    final out = <Map<String, dynamic>>[];

    void walk(dynamic value, String path, int depth) {
      if (depth > 12) return;
      if (value is List) {
        final list = JsonTools.list(value);
        final lineupPath = path.contains('lineup') || path.contains('formation') || path.contains('squad') || path.contains('member') || path.contains('starting');
        if (lineupPath) {
          for (final item in list) {
            if (_looksLikeLineupPlayer(item)) out.add(_normalizeLineup(item));
          }
        }
        for (final child in value) walk(child, path, depth + 1);
      } else if (value is Map) {
        for (final entry in value.entries) {
          walk(entry.value, '$path/${entry.key}'.toLowerCase(), depth + 1);
        }
      }
    }

    walk(json, '', 0);
    return _dedupeLineup(out);
  }

  List<Map<String, dynamic>> extractStats(Map<String, dynamic> json) {
    final out = <Map<String, dynamic>>[];

    void addStat(Map<String, dynamic> item) {
      final normalized = _normalizeStat(item);
      if (normalized.isNotEmpty) out.add(normalized);
    }

    void walk(dynamic value, String path, int depth) {
      if (depth > 12) return;
      if (value is List) {
        final list = JsonTools.list(value);
        final statPath = path.contains('stat') || path.contains('comparison') || path.contains('performance');
        if (statPath) {
          for (final item in list) addStat(item);
        }
        for (final child in value) walk(child, path, depth + 1);
      } else if (value is Map) {
        final map = JsonTools.map(value);
        if ((path.contains('stat') || path.contains('comparison')) && _hasStatValues(map)) addStat(map);
        for (final entry in value.entries) {
          walk(entry.value, '$path/${entry.key}'.toLowerCase(), depth + 1);
        }
      }
    }

    walk(json, '', 0);
    final seen = <String>{};
    final cleaned = <Map<String, dynamic>>[];
    for (final item in out) {
      final key = '${item['name']}|${item['home']}|${item['away']}';
      if ((item['name'] ?? '').toString().isNotEmpty && seen.add(key)) cleaned.add(item);
    }
    return cleaned;
  }

  Map<String, String> extractMatchInfo(Map<String, dynamic> json) {
    final info = <String, String>{};
    final game = _findGame(json, 0);
    final venue = JsonTools.map(game['venue']);
    final referee = JsonTools.map(game['referee']);

    void put(String key, dynamic value) {
      final text = value == null ? '' : '$value'.trim();
      if (text.isNotEmpty && text != 'null' && text != '0') info[key] = text;
    }

    put('الملعب', venue['name'] ?? game['venueName']);
    put('الحكم', referee['name'] ?? game['refereeName']);
    put('الجولة', game['roundName']);
    put('المرحلة', game['stageName']);
    put('الحضور', game['attendance']);
    put('الحالة', game['statusText']);
    return info;
  }

  Future<Map<String, dynamic>> _get(String path, [Map<String, String> params = const {}]) async {
    final uri = ApiConfig.uri(path, params);
    final response = await _client.get(
      uri,
      headers: const {
        'accept': 'application/json,text/plain,*/*',
        'accept-language': 'ar,en;q=0.8',
        'origin': 'https://www.365scores.com',
        'referer': 'https://www.365scores.com/',
        'user-agent': 'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/126 Mobile Safari/537.36',
      },
    ).timeout(const Duration(seconds: 20));

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception('تعذر الاتصال بالمصدر (${response.statusCode})');
    }
    final decoded = jsonDecode(utf8.decode(response.bodyBytes));
    if (decoded is Map<String, dynamic>) return decoded;
    if (decoded is Map) return decoded.map((k, v) => MapEntry('$k', v));
    if (decoded is List) return {'items': decoded};
    throw const FormatException('استجابة غير متوقعة من المصدر');
  }

  List<Map<String, dynamic>> _gameMaps(Map<String, dynamic> json) {
    final direct = JsonTools.list(json['games']);
    if (direct.isNotEmpty) return direct;

    final out = <Map<String, dynamic>>[];
    void walk(dynamic value, int depth) {
      if (depth > 11) return;
      if (value is List) {
        for (final item in JsonTools.list(value)) {
          if (_looksLikeGame(item)) out.add(item);
        }
        for (final child in value) walk(child, depth + 1);
      } else if (value is Map) {
        final map = JsonTools.map(value);
        if (_looksLikeGame(map)) out.add(map);
        for (final child in value.values) walk(child, depth + 1);
      }
    }
    walk(json, 0);
    return _dedupeGames(out);
  }

  bool _looksLikeGame(Map<String, dynamic> m) {
    final home = m['homeCompetitor'] ?? m['homeTeam'];
    final away = m['awayCompetitor'] ?? m['awayTeam'];
    return (home is Map && away is Map) && (m.containsKey('id') || m.containsKey('gameId'));
  }

  Map<String, dynamic> _findGame(Map<String, dynamic> json, int gameId) {
    for (final game in _gameMaps(json)) {
      final id = JsonTools.intValue(game['id'] ?? game['gameId']);
      if (gameId == 0 || id == gameId) return game;
    }
    return const {};
  }

  List<Competition> _competitions(Map<String, dynamic> json) {
    final out = <Competition>[];
    final seen = <int>{};

    void addList(dynamic value) {
      for (final raw in JsonTools.list(value)) {
        final c = Competition.fromJson(raw);
        if (c.id != 0 && seen.add(c.id)) out.add(c);
      }
    }

    addList(json['competitions']);
    if (out.isEmpty) {
      final best = JsonTools.findBestList(
        json,
        looksLike: (m) => m.containsKey('id') && m.containsKey('name') &&
            (m.containsKey('hasStandings') || m.containsKey('currentSeasonNum') || m.containsKey('sportId') || m.containsKey('popularityRank')),
      );
      addList(best);
    }
    return out;
  }

  List<ScorerItem> _scorers(Map<String, dynamic> json, {required int competitionId}) {
    final competitorNames = _competitorNames(json);
    final stats = JsonTools.map(json['stats']);
    var blocks = JsonTools.list(stats['athletesStats']);
    if (blocks.isEmpty) {
      blocks = JsonTools.findBestList(
        json,
        looksLike: (m) => m.containsKey('rows') && m.containsKey('statsTypes') && (m.containsKey('competitionId') || m.containsKey('name')),
      );
    }

    if (blocks.isNotEmpty) {
      final explicitIds = blocks.map((b) => JsonTools.intValue(b['competitionId'])).where((id) => id != 0).toSet();
      final matchingCompetition = blocks.where((b) {
        final id = JsonTools.intValue(b['competitionId']);
        return id == 0 || id == competitionId;
      }).toList(growable: false);
      if (explicitIds.isNotEmpty && !explicitIds.contains(competitionId)) return const [];
      final pool = matchingCompetition.isNotEmpty ? matchingCompetition : blocks;

      Map<String, dynamic>? goalsBlock;
      for (final block in pool) {
        final name = '${block['name'] ?? block['title'] ?? ''}'.toLowerCase();
        if (name == 'الأهداف' || name.contains('اهداف') || name.contains('أهداف') || name == 'goals' || name.contains('goal')) {
          goalsBlock = block;
          break;
        }
      }
      goalsBlock ??= pool.first;

      final rows = JsonTools.list(goalsBlock['rows']);
      final statTypes = JsonTools.list(goalsBlock['statsTypes']);
      final mainType = statTypes.isEmpty ? const <String, dynamic>{} : statTypes.first;
      final seen = <int>{};
      final result = rows
          .map((r) => ScorerItem.fromRow(r, competitorNames: competitorNames, statType: mainType))
          .where((s) => s.athleteId != 0 && seen.add(s.athleteId))
          .toList(growable: false);
      result.sort((a, b) => b.value.compareTo(a.value));
      return result.take(50).toList(growable: false);
    }

    final rows = JsonTools.findBestList(
      json,
      looksLike: (m) => (m.containsKey('athlete') || m.containsKey('entity') || m.containsKey('athleteId')) &&
          (m.containsKey('mainStat') || m.containsKey('goals') || m.containsKey('value') || m.containsKey('stats')),
    );
    return rows
        .map((r) => ScorerItem.fromRow(r, competitorNames: competitorNames))
        .where((s) => s.athleteId != 0)
        .take(50)
        .toList(growable: false);
  }

  Map<int, Team> _teamLookup(Map<String, dynamic> json) {
    final out = <int, Team>{};
    final direct = JsonTools.list(json['competitors']);
    for (final item in direct) {
      final team = Team.fromJson(item);
      if (team.id != 0) out[team.id] = team;
    }
    return out;
  }

  Map<int, String> _competitorNames(Map<String, dynamic> json) {
    final out = <int, String>{};
    for (final item in JsonTools.list(json['competitors'])) {
      final id = JsonTools.intValue(item['id']);
      final name = '${item['name'] ?? ''}'.trim();
      if (id != 0 && name.isNotEmpty) out[id] = name;
    }
    return out;
  }

  Map<String, dynamic> _flattenStanding(Map<String, dynamic> raw) {
    final out = <String, dynamic>{...raw};
    for (final key in const ['stats', 'values', 'standing', 'tableRow', 'record']) {
      final nested = JsonTools.map(raw[key]);
      if (nested.isNotEmpty) out.addAll(nested);
    }
    return out;
  }

  bool _looksLikeStanding(Map<String, dynamic> m) {
    final hasTeam = m['competitor'] is Map || m['team'] is Map || m['entity'] is Map ||
        m.containsKey('competitorId') || m.containsKey('teamId') || m.containsKey('participantId');
    final hasTableValue = m.containsKey('position') || m.containsKey('rank') || m.containsKey('points') ||
        m.containsKey('gamesPlayed') || m.containsKey('played') || m.containsKey('wins');
    return hasTeam && hasTableValue;
  }

  int _standingQuality(StandingRow row) {
    var q = 0;
    if (row.position > 0) q += 3;
    if (row.points != 0) q += 3;
    if (row.played != 0) q += 2;
    if (row.wins != 0 || row.draws != 0 || row.losses != 0) q += 1;
    if (row.goalsFor != 0 || row.goalsAgainst != 0) q += 1;
    return q;
  }

  bool _looksLikeEvent(Map<String, dynamic> e) {
    final hasTime = e.containsKey('gameTime') || e.containsKey('gameTimeDisplay') || e.containsKey('minute') || e.containsKey('time');
    final hasType = e.containsKey('eventType') || e.containsKey('eventTypeId') || e.containsKey('type') || e.containsKey('eventText') || e.containsKey('eventName');
    final hasActor = e.containsKey('athlete') || e.containsKey('player') || e.containsKey('athleteId') || e.containsKey('competitorId');
    return hasTime && (hasType || hasActor);
  }

  Map<String, dynamic> _normalizeEvent(Map<String, dynamic> e) {
    final athlete = JsonTools.map(e['athlete'] ?? e['player'] ?? e['mainAthlete']);
    final competitor = JsonTools.map(e['competitor'] ?? e['team']);
    return {
      ...e,
      'minute': e['minute'] ?? e['gameTime'] ?? e['time'],
      'gameTime': e['gameTime'] ?? e['minute'] ?? e['time'],
      'athleteName': e['athleteName'] ?? e['playerName'] ?? athlete['name'] ?? athlete['shortName'],
      'athleteId': e['athleteId'] ?? athlete['id'],
      'competitorId': e['competitorId'] ?? competitor['id'] ?? athlete['competitorId'],
      'eventName': e['eventName'] ?? e['eventText'] ?? e['title'] ?? e['name'] ?? JsonTools.map(e['eventType'])['name'],
    };
  }

  bool _looksLikeLineupPlayer(Map<String, dynamic> e) {
    final athlete = JsonTools.map(e['athlete'] ?? e['player']);
    final hasId = e.containsKey('athleteId') || athlete.containsKey('id') || (e.containsKey('id') && (e.containsKey('jerseyNumber') || e.containsKey('position')));
    final hasPlayerData = athlete.isNotEmpty || e.containsKey('playerName') || e.containsKey('athleteName') || e.containsKey('jerseyNumber') || e.containsKey('formationPosition');
    return hasId && hasPlayerData;
  }

  Map<String, dynamic> _normalizeLineup(Map<String, dynamic> e) {
    final athlete = JsonTools.map(e['athlete'] ?? e['player']);
    final competitor = JsonTools.map(e['competitor'] ?? e['team']);
    return {
      ...e,
      'athlete': athlete.isEmpty ? e : athlete,
      'athleteId': e['athleteId'] ?? athlete['id'] ?? e['id'],
      'name': e['name'] ?? e['athleteName'] ?? e['playerName'] ?? athlete['name'],
      'jerseyNumber': e['jerseyNumber'] ?? athlete['jerseyNumber'] ?? athlete['shirtNumber'],
      'positionName': e['positionName'] ?? athlete['positionName'] ?? JsonTools.map(athlete['position'])['name'],
      'competitorId': e['competitorId'] ?? competitor['id'] ?? athlete['competitorId'] ?? athlete['clubId'],
      'isStarter': e['isStarter'] ?? e['starter'] ?? e['isStarting'] ?? true,
    };
  }

  List<Map<String, dynamic>> _dedupeLineup(List<Map<String, dynamic>> input) {
    final seen = <String>{};
    final out = <Map<String, dynamic>>[];
    for (final item in input) {
      final key = '${item['competitorId'] ?? ''}:${item['athleteId'] ?? item['id'] ?? ''}:${item['name'] ?? ''}';
      if (key != '::' && seen.add(key)) out.add(item);
    }
    return out;
  }

  bool _hasStatValues(Map<String, dynamic> m) {
    return m.containsKey('home') || m.containsKey('away') || m.containsKey('homeValue') || m.containsKey('awayValue') ||
        m.containsKey('homeCompetitorValue') || m.containsKey('awayCompetitorValue') || m.containsKey('values') || m.containsKey('competitors');
  }

  Map<String, dynamic> _normalizeStat(Map<String, dynamic> s) {
    final name = s['name'] ?? s['title'] ?? s['statName'] ?? s['displayName'] ?? s['shortName'];
    dynamic home = s['home'] ?? s['homeValue'] ?? s['homeCompetitorValue'] ?? s['value1'];
    dynamic away = s['away'] ?? s['awayValue'] ?? s['awayCompetitorValue'] ?? s['value2'];

    final values = s['values'];
    if ((home == null || away == null) && values is List && values.length >= 2) {
      home ??= values[0] is Map ? (values[0]['value'] ?? values[0]['statValue']) : values[0];
      away ??= values[1] is Map ? (values[1]['value'] ?? values[1]['statValue']) : values[1];
    }

    final competitors = JsonTools.list(s['competitors']);
    if ((home == null || away == null) && competitors.length >= 2) {
      home ??= competitors[0]['value'] ?? competitors[0]['statValue'];
      away ??= competitors[1]['value'] ?? competitors[1]['statValue'];
    }

    if (name == null || (home == null && away == null)) return const {};
    return {'name': '$name', 'home': home == null ? '' : '$home', 'away': away == null ? '' : '$away'};
  }

  Map<String, dynamic> _findEntity(Map<String, dynamic> json, {required int id, required Set<String> keys}) {
    for (final key in keys) {
      final direct = json[key];
      if (direct is Map) {
        final map = JsonTools.map(direct);
        if (JsonTools.intValue(map['id']) == id || id == 0) return map;
      }
      if (direct is List) {
        for (final item in JsonTools.list(direct)) {
          if (JsonTools.intValue(item['id']) == id) return item;
        }
      }
    }

    Map<String, dynamic> found = const {};
    void walk(dynamic value, int depth) {
      if (found.isNotEmpty || depth > 10) return;
      if (value is Map) {
        final map = JsonTools.map(value);
        if (JsonTools.intValue(map['id']) == id && (map.containsKey('name') || map.containsKey('shortName'))) {
          found = map;
          return;
        }
        for (final child in value.values) walk(child, depth + 1);
      } else if (value is List) {
        for (final child in value) walk(child, depth + 1);
      }
    }
    walk(json, 0);
    return found;
  }

  List<Map<String, dynamic>> _dedupeMaps(List<Map<String, dynamic>> input) {
    final seen = <String>{};
    final out = <Map<String, dynamic>>[];
    for (final item in input) {
      final key = '${item['id'] ?? item['eventId'] ?? ''}|${item['gameTime'] ?? item['minute'] ?? ''}|${item['eventName'] ?? item['name'] ?? item['eventType'] ?? ''}|${item['athleteId'] ?? JsonTools.map(item['athlete'])['id'] ?? ''}';
      if (seen.add(key)) out.add(item);
    }
    return out;
  }

  List<Map<String, dynamic>> _dedupeGames(List<Map<String, dynamic>> input) {
    final seen = <int>{};
    final out = <Map<String, dynamic>>[];
    for (final item in input) {
      final id = JsonTools.intValue(item['id'] ?? item['gameId']);
      if (id != 0 && seen.add(id)) out.add(item);
    }
    return out;
  }

  String _date(DateTime date) => '${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}/${date.year}';

  void dispose() => _client.close();
}

class MatchDetailsData {
  final Map<String, dynamic> raw;
  final Map<String, dynamic> game;
  final List<Map<String, dynamic>> events;
  final List<Map<String, dynamic>> lineups;
  final List<Map<String, dynamic>> stats;
  final Map<String, String> info;

  const MatchDetailsData({
    required this.raw,
    required this.game,
    required this.events,
    required this.lineups,
    required this.stats,
    required this.info,
  });
}

class TeamProfileData {
  final Team team;
  final List<PlayerItem> players;
  final List<MatchItem> matches;
  final Map<String, dynamic> raw;
  const TeamProfileData({required this.team, required this.players, required this.matches, required this.raw});
}

class PlayerProfileData {
  final PlayerItem player;
  final Map<String, dynamic> raw;
  const PlayerProfileData({required this.player, required this.raw});
}
