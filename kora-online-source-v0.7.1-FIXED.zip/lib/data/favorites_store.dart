import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/competition.dart';
import '../models/match.dart';
import '../models/team.dart';

class FavoriteRecord {
  final String type;
  final int id;
  final String title;
  final String subtitle;
  final String imageUrl;
  final Map<String, dynamic> payload;

  const FavoriteRecord({
    required this.type,
    required this.id,
    required this.title,
    required this.subtitle,
    required this.imageUrl,
    required this.payload,
  });

  String get key => '$type:$id';

  Map<String, dynamic> toJson() => {
        'type': type,
        'id': id,
        'title': title,
        'subtitle': subtitle,
        'imageUrl': imageUrl,
        'payload': payload,
      };

  factory FavoriteRecord.fromJson(Map<String, dynamic> json) => FavoriteRecord(
        type: (json['type'] ?? '').toString(),
        id: json['id'] is num ? (json['id'] as num).toInt() : int.tryParse('${json['id']}') ?? 0,
        title: (json['title'] ?? '').toString(),
        subtitle: (json['subtitle'] ?? '').toString(),
        imageUrl: (json['imageUrl'] ?? '').toString(),
        payload: json['payload'] is Map ? Map<String, dynamic>.from(json['payload']) : <String, dynamic>{},
      );

  factory FavoriteRecord.match(MatchItem match) => FavoriteRecord(
        type: 'match',
        id: match.id,
        title: '${match.home.name} × ${match.away.name}',
        subtitle: match.competitionName,
        imageUrl: match.home.logoUrl,
        payload: match.toJson(),
      );

  factory FavoriteRecord.team(Team team) => FavoriteRecord(
        type: 'team',
        id: team.id,
        title: team.name,
        subtitle: 'فريق مفضل',
        imageUrl: team.logoUrl,
        payload: team.toJson(),
      );

  factory FavoriteRecord.competition(Competition competition) => FavoriteRecord(
        type: 'competition',
        id: competition.id,
        title: competition.name,
        subtitle: 'بطولة مفضلة',
        imageUrl: competition.logoUrl,
        payload: competition.toJson(),
      );
}

class FavoritesStore extends ChangeNotifier {
  static const _storageKey = 'kora_online_favorites_v1';
  final Map<String, FavoriteRecord> _records = {};
  bool ready = false;

  List<FavoriteRecord> get all => _records.values.toList(growable: false);
  List<FavoriteRecord> byType(String type) => all.where((e) => e.type == type).toList(growable: false);

  bool contains(String type, int id) => _records.containsKey('$type:$id');

  Future<void> load() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_storageKey);
      if (raw != null && raw.isNotEmpty) {
        final decoded = jsonDecode(raw);
        if (decoded is List) {
          for (final item in decoded.whereType<Map>()) {
            final record = FavoriteRecord.fromJson(Map<String, dynamic>.from(item));
            if (record.id != 0 && record.type.isNotEmpty) _records[record.key] = record;
          }
        }
      }
    } finally {
      ready = true;
      notifyListeners();
    }
  }

  Future<void> toggle(FavoriteRecord record) async {
    if (_records.containsKey(record.key)) {
      _records.remove(record.key);
    } else {
      _records[record.key] = record;
    }
    notifyListeners();
    await _save();
  }

  Future<void> clear() async {
    _records.clear();
    notifyListeners();
    await _save();
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = jsonEncode(_records.values.map((e) => e.toJson()).toList(growable: false));
    await prefs.setString(_storageKey, raw);
  }
}
