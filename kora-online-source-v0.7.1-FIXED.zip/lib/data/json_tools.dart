class JsonTools {
  static Map<String, dynamic> map(dynamic value) {
    if (value is Map<String, dynamic>) return value;
    if (value is Map) return value.map((k, v) => MapEntry('$k', v));
    return const <String, dynamic>{};
  }

  static List<Map<String, dynamic>> list(dynamic value) {
    if (value is! List) return const [];
    return value.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList(growable: false);
  }

  static int intValue(dynamic value, {int fallback = 0}) {
    if (value is num) return value.toInt();
    return int.tryParse('$value') ?? fallback;
  }

  static num numValue(dynamic value, {num fallback = 0}) {
    if (value is num) return value;
    return num.tryParse('$value') ?? fallback;
  }

  static String stringValue(dynamic value, {String fallback = ''}) {
    if (value == null) return fallback;
    final s = '$value';
    return s == 'null' ? fallback : s;
  }

  static dynamic findFirstByKey(dynamic root, Set<String> keys) {
    if (root is Map) {
      for (final entry in root.entries) {
        final key = '${entry.key}'.toLowerCase();
        if (keys.contains(key)) return entry.value;
      }
      for (final value in root.values) {
        final found = findFirstByKey(value, keys);
        if (found != null) return found;
      }
    } else if (root is List) {
      for (final value in root) {
        final found = findFirstByKey(value, keys);
        if (found != null) return found;
      }
    }
    return null;
  }

  static List<Map<String, dynamic>> findBestList(
    dynamic root, {
    required bool Function(Map<String, dynamic>) looksLike,
    int maxDepth = 8,
  }) {
    List<Map<String, dynamic>> best = const [];

    void walk(dynamic value, int depth) {
      if (depth > maxDepth) return;
      if (value is List) {
        final maps = list(value);
        if (maps.isNotEmpty) {
          final hits = maps.where(looksLike).length;
          if (hits > 0 && hits >= (maps.length / 2).ceil() && maps.length > best.length) {
            best = maps;
          }
        }
        for (final child in value) {
          walk(child, depth + 1);
        }
      } else if (value is Map) {
        for (final child in value.values) {
          walk(child, depth + 1);
        }
      }
    }

    walk(root, 0);
    return best;
  }

  static List<Map<String, dynamic>> findListsUnderKeys(dynamic root, Set<String> keys) {
    final out = <Map<String, dynamic>>[];

    void walk(dynamic value, int depth) {
      if (depth > 9) return;
      if (value is Map) {
        for (final entry in value.entries) {
          final key = '${entry.key}'.toLowerCase();
          if (keys.any((k) => key.contains(k))) {
            out.addAll(list(entry.value));
          }
          walk(entry.value, depth + 1);
        }
      } else if (value is List) {
        for (final child in value) {
          walk(child, depth + 1);
        }
      }
    }

    walk(root, 0);
    return out;
  }

  static String firstText(Map<String, dynamic> map, List<String> keys) {
    for (final key in keys) {
      final value = map[key];
      if (value == null) continue;
      if (value is Map) {
        final nested = JsonTools.map(value);
        final name = nested['name'] ?? nested['displayName'] ?? nested['shortName'];
        if (name != null && '$name'.trim().isNotEmpty) return '$name';
      } else if ('$value'.trim().isNotEmpty && '$value' != 'null') {
        return '$value';
      }
    }
    return '';
  }
}
