abstract final class AppIdentity {
  static const brandName = 'كورة اونلاين';
  static const storeName = 'كورة اونلاين - مباريات اليوم';
  static const tagline = 'مباريات اليوم لحظة بلحظة • v0.7.1';
  static const applicationId = 'com.koraonline.matches';
  static const versionName = '0.7.1';
}
