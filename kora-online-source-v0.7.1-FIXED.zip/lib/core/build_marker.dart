abstract final class BuildMarker {
  static const value = 'KORA_VERIFIED_BUILD_071';
}
