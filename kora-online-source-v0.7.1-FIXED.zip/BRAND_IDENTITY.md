# كورة اونلاين - مباريات اليوم

- Brand name inside the app: `كورة اونلاين`
- Google Play display name: `كورة اونلاين - مباريات اليوم`
- Tagline: `مباريات اليوم لحظة بلحظة`
- Android application ID: `com.koraonline.matches`
- Flutter package name: `kora_online_matches`
- Current app version: `0.4.0+4`

## Important
`com.koraonline.matches` is the permanent Android application ID intended for Google Play. Do not change it after the first production listing is created.
