@echo off
where flutter >nul 2>nul
if errorlevel 1 (
  echo Flutter was not found in PATH.
  echo Install Flutter Stable then re-run this file.
  pause
  exit /b 1
)
flutter create --platforms=android --org=com.koraonline --project-name=matches .
flutter pub get
echo.
echo Project prepared. Run: flutter run
pause
