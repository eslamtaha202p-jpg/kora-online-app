import 'dart:async';

import 'package:flutter/material.dart';

import '../core/app_theme.dart';
import '../data/favorites_store.dart';
import '../data/settings_store.dart';
import '../data/sports_repository.dart';
import '../models/match.dart';
import '../widgets/app_states.dart';
import '../widgets/match_card.dart';
import 'match_details_screen.dart';

class MatchesScreen extends StatefulWidget {
  final SportsRepository repository;
  final FavoritesStore favorites;
  final SettingsStore settings;
  const MatchesScreen({super.key, required this.repository, required this.favorites, required this.settings});

  @override
  State<MatchesScreen> createState() => _MatchesScreenState();
}

class _MatchesScreenState extends State<MatchesScreen> {
  DateTime date = DateTime.now();
  bool loading = true;
  Object? error;
  List<MatchItem> matches = const [];
  int filter = 0;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    widget.settings.addListener(_settingsChanged);
    _scheduleRefresh();
    _load();
  }

  @override
  void dispose() {
    _timer?.cancel();
    widget.settings.removeListener(_settingsChanged);
    super.dispose();
  }

  void _settingsChanged() {
    _scheduleRefresh();
    if (mounted) setState(() {});
  }

  void _scheduleRefresh() {
    _timer?.cancel();
    if (!widget.settings.autoRefresh) return;
    _timer = Timer.periodic(Duration(seconds: widget.settings.refreshSeconds), (_) {
      if (_isToday(date) && mounted) _load(silent: true);
    });
  }

  Future<void> _load({bool silent = false}) async {
    if (!silent) setState(() { loading = true; error = null; });
    try {
      final data = await widget.repository.fetchMatchesForDate(date);
      if (!mounted) return;
      setState(() { matches = data; loading = false; });
    } catch (e) {
      if (!mounted) return;
      setState(() { error = e; loading = false; });
    }
  }

  List<MatchItem> get visible {
    Iterable<MatchItem> data = matches;
    if (filter == 1) data = data.where((m) => m.isLive);
    if (filter == 2) data = data.where((m) => m.isUpcoming);
    if (filter == 3) data = data.where((m) => m.isFinished);
    final list = data.toList(growable: false);
    if (widget.settings.liveFirst) {
      list.sort((a, b) {
        if (a.isLive != b.isLive) return a.isLive ? -1 : 1;
        final x = a.startTime?.millisecondsSinceEpoch ?? 0;
        final y = b.startTime?.millisecondsSinceEpoch ?? 0;
        return x.compareTo(y);
      });
    }
    return list;
  }

  void _move(int days) {
    setState(() => date = DateTime(date.year, date.month, date.day + days));
    _load();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      bottom: false,
      child: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 8),
          child: Row(children: [
            const Expanded(child: Text('المباريات', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900))),
            IconButton(onPressed: _load, icon: const Icon(Icons.refresh_rounded)),
          ]),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Row(children: [
            IconButton.filledTonal(onPressed: () => _move(-1), icon: const Icon(Icons.chevron_right_rounded)),
            Expanded(child: Center(child: Column(children: [
              Text(_dayLabel(date), style: const TextStyle(fontWeight: FontWeight.w900)),
              Text('${date.day}/${date.month}/${date.year}', style: const TextStyle(color: AppColors.muted, fontSize: 10)),
            ]))),
            IconButton.filledTonal(onPressed: () => _move(1), icon: const Icon(Icons.chevron_left_rounded)),
          ]),
        ),
        const SizedBox(height: 8),
        SizedBox(
          height: 42,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            itemCount: 4,
            separatorBuilder: (_, __) => const SizedBox(width: 7),
            itemBuilder: (_, i) => ChoiceChip(
              label: Text(const ['الكل', 'مباشر', 'قادمة', 'انتهت'][i]),
              selected: filter == i,
              onSelected: (_) => setState(() => filter = i),
            ),
          ),
        ),
        const SizedBox(height: 6),
        Expanded(
          child: loading && matches.isEmpty
              ? const AppLoading()
              : error != null && matches.isEmpty
                  ? AppError(error: error!, onRetry: _load)
                  : RefreshIndicator(
                      onRefresh: _load,
                      color: AppColors.primary,
                      child: visible.isEmpty
                          ? const ListView(children: [SizedBox(height: 240, child: EmptyState(text: 'لا توجد مباريات في هذا اليوم'))])
                          : ListView.separated(
                              padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                              itemCount: visible.length,
                              separatorBuilder: (_, __) => const SizedBox(height: 10),
                              itemBuilder: (_, i) => MatchCard(
                                match: visible[i],
                                compact: widget.settings.compactCards,
                                onTap: () => Navigator.of(context).push(MaterialPageRoute(
                                  builder: (_) => MatchDetailsScreen(repository: widget.repository, favorites: widget.favorites, match: visible[i]),
                                )),
                              ),
                            ),
                    ),
        ),
      ]),
    );
  }

  bool _isToday(DateTime d) {
    final n = DateTime.now();
    return d.year == n.year && d.month == n.month && d.day == n.day;
  }

  String _dayLabel(DateTime d) {
    final now = DateTime.now();
    final a = DateTime(d.year, d.month, d.day);
    final b = DateTime(now.year, now.month, now.day);
    final diff = a.difference(b).inDays;
    if (diff == 0) return 'اليوم';
    if (diff == 1) return 'غدًا';
    if (diff == -1) return 'أمس';
    return 'مباريات ${d.day}/${d.month}';
  }
}
