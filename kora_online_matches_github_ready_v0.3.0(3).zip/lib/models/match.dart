import 'team.dart';

class MatchItem {
  final int id;
  final int competitionId;
  final String competitionName;
  final int competitionImageVersion;
  final String roundName;
  final String stageName;
  final DateTime? startTime;
  final int statusGroup;
  final String statusText;
  final String shortStatusText;
  final int gameTime;
  final String gameTimeDisplay;
  final Team home;
  final Team away;
  final String venueName;
  final bool hasLineups;
  final bool hasStats;
  final bool hasStandings;
  final bool hasTvNetworks;
  final bool hasLiveStreaming;
  final bool hasPreviousMeetings;
  final String aggregateText;

  const MatchItem({
    required this.id,
    required this.competitionId,
    required this.competitionName,
    required this.competitionImageVersion,
    required this.roundName,
    required this.stageName,
    required this.startTime,
    required this.statusGroup,
    required this.statusText,
    required this.shortStatusText,
    required this.gameTime,
    required this.gameTimeDisplay,
    required this.home,
    required this.away,
    required this.venueName,
    required this.hasLineups,
    required this.hasStats,
    required this.hasStandings,
    required this.hasTvNetworks,
    required this.hasLiveStreaming,
    required this.hasPreviousMeetings,
    required this.aggregateText,
  });

  factory MatchItem.fromJson(Map<String, dynamic> json) {
    final venue = _map(json['venue']);
    final competition = _map(json['competition']);
    return MatchItem(
      id: _toInt(json['id'] ?? json['gameId']),
      competitionId: _toInt(json['competitionId'] ?? competition['id']),
      competitionName: (json['competitionDisplayName'] ?? competition['name'] ?? json['competitionName'] ?? 'بطولة').toString(),
      competitionImageVersion: _toInt(competition['imageVersion'], fallback: 1),
      roundName: (json['roundName'] ?? '').toString(),
      stageName: (json['stageName'] ?? '').toString(),
      startTime: DateTime.tryParse((json['startTime'] ?? '').toString())?.toLocal(),
      statusGroup: _toInt(json['statusGroup']),
      statusText: (json['statusText'] ?? '').toString(),
      shortStatusText: (json['shortStatusText'] ?? '').toString(),
      gameTime: _toInt(json['gameTime'], fallback: -1),
      gameTimeDisplay: (json['gameTimeDisplay'] ?? '').toString(),
      home: Team.fromJson(_map(json['homeCompetitor'] ?? json['homeTeam'])),
      away: Team.fromJson(_map(json['awayCompetitor'] ?? json['awayTeam'])),
      venueName: (venue['name'] ?? '').toString(),
      hasLineups: json['hasLineups'] == true,
      hasStats: json['hasStats'] == true,
      hasStandings: json['hasStandings'] == true,
      hasTvNetworks: json['hasTVNetworks'] == true,
      hasLiveStreaming: json['hasLiveStreaming'] == true,
      hasPreviousMeetings: json['hasPreviousMeetings'] == true,
      aggregateText: (json['aggregateText'] ?? json['shortAggregateText'] ?? '').toString(),
    );
  }

  bool get isLive => statusGroup == 3 || (!isFinished && gameTime > 0);
  bool get isFinished => statusGroup == 4 || statusText.contains('انته') || statusText.contains('بعد الوقت');
  bool get isUpcoming => !isLive && !isFinished;

  String get kickoffLabel {
    if (isLive && gameTimeDisplay.isNotEmpty) return gameTimeDisplay;
    final d = startTime;
    if (d == null) return statusText.isEmpty ? '—' : statusText;
    return '${d.hour.toString().padLeft(2, '0')}:${d.minute.toString().padLeft(2, '0')}';
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'competitionId': competitionId,
        'competitionDisplayName': competitionName,
        'roundName': roundName,
        'stageName': stageName,
        'startTime': startTime?.toIso8601String(),
        'statusGroup': statusGroup,
        'statusText': statusText,
        'shortStatusText': shortStatusText,
        'gameTime': gameTime,
        'gameTimeDisplay': gameTimeDisplay,
        'homeCompetitor': home.toJson(),
        'awayCompetitor': away.toJson(),
        'venue': {'name': venueName},
        'hasLineups': hasLineups,
        'hasStats': hasStats,
        'hasStandings': hasStandings,
        'hasTVNetworks': hasTvNetworks,
        'hasLiveStreaming': hasLiveStreaming,
        'hasPreviousMeetings': hasPreviousMeetings,
        'aggregateText': aggregateText,
      };

  static Map<String, dynamic> _map(dynamic value) {
    if (value is Map<String, dynamic>) return value;
    if (value is Map) return value.map((k, v) => MapEntry('$k', v));
    return const <String, dynamic>{};
  }

  static int _toInt(dynamic value, {int fallback = 0}) {
    if (value is num) return value.toInt();
    return int.tryParse('$value') ?? fallback;
  }
}
