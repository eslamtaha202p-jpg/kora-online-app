import '../core/api_config.dart';

class ScorerItem {
  final int athleteId;
  final int teamId;
  final String name;
  final String shortName;
  final String teamName;
  final int imageVersion;
  final num value;
  final String valueName;
  final String secondary;

  const ScorerItem({
    required this.athleteId,
    required this.teamId,
    required this.name,
    required this.shortName,
    required this.teamName,
    required this.imageVersion,
    required this.value,
    required this.valueName,
    required this.secondary,
  });

  factory ScorerItem.fromRow(
    Map<String, dynamic> row, {
    Map<int, String> competitorNames = const {},
    Map<String, dynamic>? statType,
  }) {
    final entity = _map(row['entity'] ?? row['athlete']);
    final mainStat = _map(row['mainStat']);
    final stats = _list(row['stats']);

    int wantedTypeId = _toInt(statType?['typeId']);
    if (wantedTypeId == 0) wantedTypeId = _toInt(mainStat['typeId']);

    Map<String, dynamic> stat = const {};
    if (wantedTypeId != 0) {
      for (final item in stats) {
        if (_toInt(item['typeId']) == wantedTypeId) {
          stat = item;
          break;
        }
      }
    }
    if (stat.isEmpty && stats.isNotEmpty) stat = stats.first;

    final rawValue = stat['value'] ?? mainStat['value'] ?? row['value'] ?? row['goals'] ?? 0;
    final teamId = _toInt(entity['competitorId'] ?? row['competitorId']);

    return ScorerItem(
      athleteId: _toInt(entity['id'] ?? row['athleteId']),
      teamId: teamId,
      name: (entity['name'] ?? row['name'] ?? 'لاعب').toString(),
      shortName: (entity['shortName'] ?? entity['name'] ?? row['name'] ?? 'لاعب').toString(),
      teamName: (entity['competitorName'] ?? entity['clubName'] ?? row['competitorName'] ?? competitorNames[teamId] ?? '').toString(),
      imageVersion: _toInt(entity['imageVersion'], fallback: 1),
      value: rawValue is num ? rawValue : num.tryParse('$rawValue') ?? 0,
      valueName: (statType?['name'] ?? mainStat['name'] ?? row['statName'] ?? 'الأهداف').toString(),
      secondary: (row['secondaryStatName'] ?? row['secondary'] ?? '').toString(),
    );
  }

  String get imageUrl => ApiConfig.athletePhoto(id: athleteId);

  static Map<String, dynamic> _map(dynamic value) {
    if (value is Map<String, dynamic>) return value;
    if (value is Map) return value.map((k, v) => MapEntry('$k', v));
    return const <String, dynamic>{};
  }

  static List<Map<String, dynamic>> _list(dynamic value) {
    if (value is! List) return const [];
    return value.whereType<Map>().map((e) => Map<String, dynamic>.from(e)).toList(growable: false);
  }

  static int _toInt(dynamic value, {int fallback = 0}) {
    if (value is num) return value.toInt();
    return int.tryParse('$value') ?? fallback;
  }
}
