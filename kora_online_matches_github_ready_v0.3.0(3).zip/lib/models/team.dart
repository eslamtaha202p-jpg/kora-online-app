import '../core/api_config.dart';

class Team {
  final int id;
  final String name;
  final String symbolicName;
  final int imageVersion;
  final int? score;
  final String colorHex;
  final int countryId;

  const Team({
    required this.id,
    required this.name,
    required this.symbolicName,
    required this.imageVersion,
    this.score,
    this.colorHex = '#14B8FF',
    this.countryId = 0,
  });

  factory Team.fromJson(Map<String, dynamic> json) => Team(
        id: _toInt(json['id'] ?? json['competitorId'] ?? json['teamId']),
        name: (json['name'] ?? json['competitorName'] ?? json['teamName'] ?? 'فريق').toString(),
        symbolicName: (json['symbolicName'] ?? json['shortName'] ?? '').toString(),
        imageVersion: _toInt(json['imageVersion'], fallback: 1),
        score: _nullableInt(json['score']),
        colorHex: (json['color'] ?? '#14B8FF').toString(),
        countryId: _toInt(json['countryId']),
      );

  String get logoUrl => ApiConfig.competitorLogo(id: id);

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'symbolicName': symbolicName,
        'imageVersion': imageVersion,
        'score': score,
        'color': colorHex,
        'countryId': countryId,
      };

  static int _toInt(dynamic value, {int fallback = 0}) {
    if (value is num) return value.toInt();
    return int.tryParse('$value') ?? fallback;
  }

  static int? _nullableInt(dynamic value) {
    if (value == null) return null;
    if (value is num) return value.toInt();
    return int.tryParse('$value');
  }
}
