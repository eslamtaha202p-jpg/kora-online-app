import 'team.dart';

class StandingRow {
  final int position;
  final Team team;
  final int played;
  final int wins;
  final int draws;
  final int losses;
  final int goalsFor;
  final int goalsAgainst;
  final int points;
  final String form;

  const StandingRow({
    required this.position,
    required this.team,
    required this.played,
    required this.wins,
    required this.draws,
    required this.losses,
    required this.goalsFor,
    required this.goalsAgainst,
    required this.points,
    required this.form,
  });

  factory StandingRow.fromJson(Map<String, dynamic> json, {Map<int, Team> teams = const {}}) {
    final competitor = _map(json['competitor'] ?? json['team'] ?? json['participant'] ?? json['entity']);
    final competitorId = _firstInt(json, ['competitorId', 'teamId', 'participantId', 'entityId']);
    final team = competitor.isNotEmpty
        ? Team.fromJson(competitor)
        : (teams[competitorId] ?? Team.fromJson({...json, if (competitorId != 0) 'id': competitorId}));

    return StandingRow(
      position: _firstInt(json, ['position', 'rank', 'place', 'order', 'rowNum', 'standingPosition']),
      team: team,
      played: _firstInt(json, ['gamesPlayed', 'played', 'games', 'matches', 'totalGames']),
      wins: _firstInt(json, ['wins', 'won', 'win']),
      draws: _firstInt(json, ['draws', 'draw', 'ties']),
      losses: _firstInt(json, ['losses', 'lost', 'lose']),
      goalsFor: _firstInt(json, ['goalsFor', 'goalsScored', 'scoreFor', 'scoresFor', 'for']),
      goalsAgainst: _firstInt(json, ['goalsAgainst', 'goalsConceded', 'scoreAgainst', 'scoresAgainst', 'against']),
      points: _firstInt(json, ['points', 'pts', 'value', 'totalPoints']),
      form: (json['form'] ?? json['recentForm'] ?? json['lastGamesForm'] ?? '').toString(),
    );
  }

  static int _firstInt(Map<String, dynamic> json, List<String> keys) {
    for (final k in keys) {
      final v = json[k];
      if (v is num) return v.toInt();
      final parsed = int.tryParse('$v');
      if (parsed != null) return parsed;
    }
    return 0;
  }

  static Map<String, dynamic> _map(dynamic value) {
    if (value is Map<String, dynamic>) return value;
    if (value is Map) return value.map((k, v) => MapEntry('$k', v));
    return const <String, dynamic>{};
  }
}
