import 'dart:convert';

import 'package:http/http.dart' as http;

import '../core/api_config.dart';
import '../models/competition.dart';
import '../models/match.dart';
import '../models/player.dart';
import '../models/prediction.dart';
import '../models/scorer.dart';
import '../models/standing_row.dart';
import '../models/team.dart';
import 'json_tools.dart';

class SportsRepository {
  final http.Client _client;

  SportsRepository({http.Client? client}) : _client = client ?? http.Client();

  Future<List<MatchItem>> fetchMatchesForDate(DateTime date) async {
    final d = _date(date);
    final json = await _get('/web/games/all/', {'startDate': d, 'endDate': d});
    return parseMatches(json);
  }

  Future<List<MatchItem>> fetchLiveMatches() async {
    final json = await _get('/web/games/current/');
    final all = parseMatches(json);
    final live = all.where((m) => m.isLive).toList(growable: false);
    return live.isNotEmpty ? live : all.where((m) => m.statusGroup == 3).toList(growable: false);
  }

  Future<List<Competition>> fetchTopCompetitions({int limit = 50}) async {
    final out = <Competition>[];
    final seen = <int>{};

    Future<void> addFrom(Future<Map<String, dynamic>> task) async {
      try {
        final json = await task;
        for (final c in _competitions(json)) {
          if (c.id != 0 && seen.add(c.id)) out.add(c);
        }
      } catch (_) {}
    }

    await addFrom(_get('/web/competitions/top/', {'limit': '$limit'}));
    await addFrom(_get('/web/competitions/', {'withSeasons': 'true'}));

    return out.take(limit).toList(growable: false);
  }

  /// Catalog used by the competitions tab. The public web service does not
  /// expose one stable "all competitions" payload in every context, so we
  /// merge the catalog response, top competitions, and competitions actually
  /// active around today. This avoids the old top-10-only behavior.
  Future<List<Competition>> fetchCompetitionsCatalog({DateTime? around}) async {
    final day = around ?? DateTime.now();
    final responses = await Future.wait<Map<String, dynamic>?>([
      _get('/web/competitions/top/', {'limit': '200'}).then<Map<String, dynamic>?>((v) => v).catchError((_) => null),
      _get('/web/competitions/', {'withSeasons': 'true'}).then<Map<String, dynamic>?>((v) => v).catchError((_) => null),
      _get('/web/games/all/', {'startDate': _date(day.subtract(const Duration(days: 2))), 'endDate': _date(day.add(const Duration(days: 4)))})
          .then<Map<String, dynamic>?>((v) => v)
          .catchError((_) => null),
    ]);

    final byId = <int, Competition>{};
    for (final json in responses.whereType<Map<String, dynamic>>()) {
      for (final c in _competitions(json)) {
        if (c.id != 0) byId[c.id] = c;
      }
      for (final m in parseMatches(json)) {
        if (m.competitionId == 0) continue;
        byId.putIfAbsent(
          m.competitionId,
          () => Competition(
            id: m.competitionId,
            name: m.competitionName,
            nameForUrl: '',
            imageVersion: m.competitionImageVersion,
            hasStandings: m.hasStandings,
          ),
        );
      }
    }

    final list = byId.values.toList();
    list.sort((a, b) {
      if (a.hasStandings != b.hasStandings) return a.hasStandings ? -1 : 1;
      return a.name.compareTo(b.name);
    });
    return list;
  }

  Future<List<MatchItem>> fetchCompetitionMatches(int competitionId) async {
    var json = await _get('/web/games/all/', {'competitions': '$competitionId'});
    var matches = parseMatches(json).where((m) => m.competitionId == 0 || m.competitionId == competitionId).toList(growable: false);
    if (matches.isNotEmpty) return matches;

    final now = DateTime.now();
    json = await _get('/web/games/all/', {
      'competitions': '$competitionId',
      'startDate': _date(now.subtract(const Duration(days: 45))),
      'endDate': _date(now.add(const Duration(days: 75))),
    });
    matches = parseMatches(json).where((m) => m.competitionId == 0 || m.competitionId == competitionId).toList(growable: false);
    matches.sort((a, b) {
      final x = a.startTime?.millisecondsSinceEpoch ?? 0;
      final y = b.startTime?.millisecondsSinceEpoch ?? 0;
      return x.compareTo(y);
    });
    return matches;
  }

  Future<List<StandingRow>> fetchStandings(int competitionId) async {
    final json = await _get('/web/standings/', {'competitions': '$competitionId'});
    final teamLookup = _teamLookup(json);
    final candidates = <Map<String, dynamic>>[];

    void collect(dynamic value, String path, int depth) {
      if (depth > 11) return;
      if (value is List) {
        final list = JsonTools.list(value);
        final pathLooksUseful = path.contains('standing') || path.contains('table') || path.contains('row') || path.contains('group');
        for (final item in list) {
          final flat = _flattenStanding(item);
          if ((pathLooksUseful || _looksLikeStanding(flat)) && _looksLikeStanding(flat)) {
            candidates.add(flat);
          }
        }
        for (final child in value) {
          collect(child, path, depth + 1);
        }
      } else if (value is Map) {
        for (final entry in value.entries) {
          collect(entry.value, '$path/${entry.key}'.toLowerCase(), depth + 1);
        }
      }
    }

    collect(json, '', 0);

    final byTeam = <int, StandingRow>{};
    final zeroId = <StandingRow>[];
    for (final raw in candidates) {
      final row = StandingRow.fromJson(raw, teams: teamLookup);
      if (row.team.id != 0) {
        final old = byTeam[row.team.id];
        if (old == null || _standingQuality(row) > _standingQuality(old)) byTeam[row.team.id] = row;
      } else if (row.team.name != 'فريق') {
        zeroId.add(row);
      }
    }

    final parsed = [...byTeam.values, ...zeroId];
    parsed.sort((a, b) {
      if (a.position != 0 && b.position != 0) return a.position.compareTo(b.position);
      if (a.position != 0) return -1;
      if (b.position != 0) return 1;
      final byPoints = b.points.compareTo(a.points);
      if (byPoints != 0) return byPoints;
      return (b.goalsFor - b.goalsAgainst).compareTo(a.goalsFor - a.goalsAgainst);
    });
    return parsed;
  }

  Future<List<ScorerItem>> fetchScorers(int competitionId) async {
    final json = await _get('/web/stats/', {'competitions': '$competitionId', 'withSeasons': 'true'});
    return _scorers(json, competitionId: competitionId);
  }

  Future<MatchPrediction?> fetchPrediction(int competitionId, int gameId) async {
    final json = await _get('/web/games/predictions/', {'competitions': '$competitionId'});
    for (final game in _gameMaps(json)) {
      final prediction = MatchPrediction.fromGameJson(game);
      if (prediction != null && prediction.gameId == gameId) return prediction;
    }

    final promoted = JsonTools.findBestList(
      json,
      looksLike: (m) => m.containsKey('gameId') && (m.containsKey('options') || m.containsKey('question') || m.containsKey('prediction')),
    );
    for (final game in promoted) {
      final prediction = MatchPrediction.fromGameJson(game);
      if (prediction != null && prediction.gameId == gameId) return prediction;
    }
    return null;
  }

  Future<Map<String, dynamic>> fetchMatchDetails(int gameId) => _get('/web/game/', {'gameId': '$gameId'});

  Future<MatchDetailsData> fetchMatchDetailsData(int gameId) async {
    final raw = await fetchMatchDetails(gameId);
    final gameMap = _findGame(raw, gameId);
    return MatchDetailsData(
      raw: raw,
      game: gameMap,
      events: extractEvents(raw),
      lineups: extractLineupPlayers(raw),
      stats: extractStats(raw),
      info: extractMatchInfo(raw),
    );
  }

  Future<List<MatchItem>> fetchHeadToHead(int gameId) async {
    final json = await _get('/web/h2h/', {'gameId': '$gameId'});
    final matches = parseMatches(json);
    final seen = <int>{};
    return matches.where((m) => m.id != 0 && m.id != gameId && seen.add(m.id)).toList(growable: false);
  }

  Future<TeamProfileData> fetchTeamProfile(int teamId) async {
    final json = await _get('/web/teams/', {'team': '$teamId'});
    final teamMap = _findEntity(json, id: teamId, keys: const {'teams', 'competitors', 'team', 'competitor'});
    final team = Team.fromJson(teamMap.isEmpty ? {'id': teamId, 'name': 'الفريق'} : teamMap);

    final competitorNames = _competitorNames(json);
    final directAthletes = JsonTools.list(json['athletes']);
    var playerMaps = directAthletes;
    if (playerMaps.isEmpty) {
      playerMaps = JsonTools.findBestList(
        json,
        looksLike: (m) => (m.containsKey('athlete') || m.containsKey('athleteId') || m.containsKey('positionName')) &&
            (m.containsKey('id') || m.containsKey('athleteId') || m.containsKey('athlete')),
      );
    }

    final seen = <int>{};
    final players = playerMaps.map((p) {
      final normalized = Map<String, dynamic>.from(p);
      final athlete = JsonTools.map(normalized['athlete']);
      final clubId = JsonTools.intValue(athlete['clubId'] ?? normalized['clubId'] ?? athlete['competitorId']);
      if ((athlete['clubName'] == null || '${athlete['clubName']}'.isEmpty) && clubId != 0 && competitorNames[clubId] != null) {
        if (athlete.isNotEmpty) normalized['athlete'] = {...athlete, 'clubName': competitorNames[clubId]};
      }
      return PlayerItem.fromJson(normalized);
    }).where((p) => p.id != 0 && seen.add(p.id)).toList(growable: false);

    final matches = parseMatches(json);
    return TeamProfileData(team: team, players: players, matches: matches, raw: json);
  }

  Future<PlayerProfileData> fetchPlayerProfile(int athleteId) async {
    final json = await _get('/web/athletes/', {'athlete': '$athleteId'});
    var athleteMap = _findEntity(json, id: athleteId, keys: const {'athletes', 'athlete', 'players', 'player'});
    if (athleteMap.isEmpty) {
      final athletes = JsonTools.list(json['athletes']);
      if (athletes.isNotEmpty) athleteMap = athletes.first;
    }
    final player = PlayerItem.fromJson(athleteMap.isEmpty ? {'id': athleteId, 'name': 'اللاعب'} : athleteMap);
    return PlayerProfileData(player: player, raw: json);
  }

  List<MatchItem> parseMatches(Map<String, dynamic> json) {
    final seen = <int>{};
    final out = <MatchItem>[];
    for (final raw in _gameMaps(json)) {
      final m = MatchItem.fromJson(raw);
      if (m.id != 0 && seen.add(m.id)) out.add(m);
    }
    return out;
  }

  List<Map<String, dynamic>> extractEvents(Map<String, dynamic> json) {
    final out = <Map<String, dynamic>>[];

    void walk(dynamic value, String path, int depth) {
      if (depth > 12) return;
      if (value is List) {
        final list = JsonTools.list(value);
        final eventPath = path.contains('event') || path.contains('incident') || path.contains('timeline') || path.contains('playbyplay');
        for (final item in list) {
          if ((eventPath && _looksLikeEvent(item)) || _looksLikeEvent(item)) out.add(_normalizeEvent(item));
        }
        for (final child in value) {
          walk(child, path, depth + 1);
        }
      } else if (value is Map) {
        final map = JsonTools.map(value);
        if (_looksLikeEvent(map) && (path.contains('event') || path.contains('incident') || map.containsKey('eventTypeId'))) {
          out.add(_normalizeEvent(map));
        }
        for (final entry in value.entries) {
          walk(entry.value, '$path/${entry.key}'.toLowerCase(), depth + 1);
        }
      }
    }

    walk(json, '', 0);
    final deduped = _dedupeMaps(out);
    deduped.sort((a, b) {
      final x = JsonTools.intValue(a['gameTime'] ?? a['minute'] ?? a['time']);
      final y = JsonTools.intValue(b['gameTime'] ?? b['minute'] ?? b['time']);
      return y.compareTo(x);
    });
    return deduped;
  }

  List<Map<String, dynamic>> extractLineupPlayers(Map<String, dynamic> json) {
    final out = <Map<String, dynamic>>[];

    void walk(dynamic value, String path, int depth) {
      if (depth > 12) return;
      if (value is List) {
        final list = JsonTools.list(value);
        final lineupPath = path.contains('lineup') || path.contains('formation') || path.contains('squad') || path.contains('member') || path.contains('starting');
        if (lineupPath) {
          for (final item in list) {
            if (_looksLikeLineupPlayer(item)) out.add(_normalizeLineup(item));
          }
        }
        for (final child in value) walk(child, path, depth + 1);
      } else if (value is Map) {
        for (final entry in value.entries) {
          walk(entry.value, '$path/${entry.key}'.toLowerCase(), depth + 1);
        }
      }
    }

    walk(json, '', 0);
    return _dedupeLineup(out);
  }

  List<Map<String, dynamic>> extractStats(Map<String, dynamic> json) {
    final out = <Map<String, dynamic>>[];

    void addStat(Map<String, dynamic> item) {
      final normalized = _normalizeStat(item);
      if (normalized.isNotEmpty) out.add(normalized);
    }

    void walk(dynamic value, String path, int depth) {
      if (depth > 12) return;
      if (value is List) {
        final list = JsonTools.list(value);
        final statPath = path.contains('stat') || path.contains('comparison') || path.contains('performance');
        if (statPath) {
          for (final item in list) addStat(item);
        }
        for (final child in value) walk(child, path, depth + 1);
      } else if (value is Map) {
        final map = JsonTools.map(value);
        if ((path.contains('stat') || path.contains('comparison')) && _hasStatValues(map)) addStat(map);
        for (final entry in value.entries) {
          walk(entry.value, '$path/${entry.key}'.toLowerCase(), depth + 1);
        }
      }
    }

    walk(json, '', 0);
    final seen = <String>{};
    final cleaned = <Map<String, dynamic>>[];
    for (final item in out) {
      final key = '${item['name']}|${item['home']}|${item['away']}';
      if ((item['name'] ?? '').toString().isNotEmpty && seen.add(key)) cleaned.add(item);
    }
    return cleaned;
  }

  Map<String, String> extractMatchInfo(Map<String, dynamic> json) {
    final info = <String, String>{};
    final game = _findGame(json, 0);
    final venue = JsonTools.map(game['venue']);
    final referee = JsonTools.map(game['referee']);

    void put(String key, dynamic value) {
      final text = value == null ? '' : '$value'.trim();
      if (text.isNotEmpty && text != 'null' && text != '0') info[key] = text;
    }

    put('الملعب', venue['name'] ?? game['venueName']);
    put('الحكم', referee['name'] ?? game['refereeName']);
    put('الجولة', game['roundName']);
    put('المرحلة', game['stageName']);
    put('الحضور', game['attendance']);
    put('الحالة', game['statusText']);
    return info;
  }

  Future<Map<String, dynamic>> _get(String path, [Map<String, String> params = const {}]) async {
    final uri = ApiConfig.uri(path, params);
    final response = await _client.get(
      uri,
      headers: const {
        'accept': 'application/json,text/plain,*/*',
        'accept-language': 'ar,en;q=0.8',
        'user-agent': 'KoraOnline/0.6 Android',
      },
    ).timeout(const Duration(seconds: 20));

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception('تعذر الاتصال بالمصدر (${response.statusCode})');
    }
    final decoded = jsonDecode(utf8.decode(response.bodyBytes));
    if (decoded is Map<String, dynamic>) return decoded;
    if (decoded is Map) return decoded.map((k, v) => MapEntry('$k', v));
    if (decoded is List) return {'items': decoded};
    throw const FormatException('استجابة غير متوقعة من المصدر');
  }

  List<Map<String, dynamic>> _gameMaps(Map<String, dynamic> json) {
    final direct = JsonTools.list(json['games']);
    if (direct.isNotEmpty) return direct;

    final out = <Map<String, dynamic>>[];
    void walk(dynamic value, int depth) {
      if (depth > 11) return;
      if (value is List) {
        for (final item in JsonTools.list(value)) {
          if (_looksLikeGame(item)) out.add(item);
        }
        for (final child in value) walk(child, depth + 1);
      } else if (value is Map) {
        final map = JsonTools.map(value);
        if (_looksLikeGame(map)) out.add(map);
        for (final child in value.values) walk(child, depth + 1);
      }
    }
    walk(json, 0);
    return _dedupeGames(out);
  }

  bool _looksLikeGame(Map<String, dynamic> m) {
    final home = m['homeCompetitor'] ?? m['homeTeam'];
    final away = m['awayCompetitor'] ?? m['awayTeam'];
    return (home is Map && away is Map) && (m.containsKey('id') || m.containsKey('gameId'));
  }

  Map<String, dynamic> _findGame(Map<String, dynamic> json, int gameId) {
    for (final game in _gameMaps(json)) {
      final id = JsonTools.intValue(game['id'] ?? game['gameId']);
      if (gameId == 0 || id == gameId) return game;
    }
    return const {};
  }

  List<Competition> _competitions(Map<String, dynamic> json) {
    final out = <Competition>[];
    final seen = <int>{};

    void addList(dynamic value) {
      for (final raw in JsonTools.list(value)) {
        final c = Competition.fromJson(raw);
        if (c.id != 0 && seen.add(c.id)) out.add(c);
      }
    }

    addList(json['competitions']);
    if (out.isEmpty) {
      final best = JsonTools.findBestList(
        json,
        looksLike: (m) => m.containsKey('id') && m.containsKey('name') &&
            (m.containsKey('hasStandings') || m.containsKey('currentSeasonNum') || m.containsKey('sportId') || m.containsKey('popularityRank')),
      );
      addList(best);
    }
    return out;
  }

  List<ScorerItem> _scorers(Map<String, dynamic> json, {required int competitionId}) {
    final competitorNames = _competitorNames(json);
    final stats = JsonTools.map(json['stats']);
    var blocks = JsonTools.list(stats['athletesStats']);
    if (blocks.isEmpty) {
      blocks = JsonTools.findBestList(
        json,
        looksLike: (m) => m.containsKey('rows') && m.containsKey('statsTypes') && (m.containsKey('competitionId') || m.containsKey('name')),
      );
    }

    if (blocks.isNotEmpty) {
      final explicitIds = blocks.map((b) => JsonTools.intValue(b['competitionId'])).where((id) => id != 0).toSet();
      final matchingCompetition = blocks.where((b) {
        final id = JsonTools.intValue(b['competitionId']);
        return id == 0 || id == competitionId;
      }).toList(growable: false);
      if (explicitIds.isNotEmpty && !explicitIds.contains(competitionId)) return const [];
      final pool = matchingCompetition.isNotEmpty ? matchingCompetition : blocks;

      Map<String, dynamic>? goalsBlock;
      for (final block in pool) {
        final name = '${block['name'] ?? block['title'] ?? ''}'.toLowerCase();
        if (name == 'الأهداف' || name.contains('اهداف') || name.contains('أهداف') || name == 'goals' || name.contains('goal')) {
          goalsBlock = block;
          break;
        }
      }
      goalsBlock ??= pool.first;

      final rows = JsonTools.list(goalsBlock['rows']);
      final statTypes = JsonTools.list(goalsBlock['statsTypes']);
      final mainType = statTypes.isEmpty ? const <String, dynamic>{} : statTypes.first;
      final seen = <int>{};
      final result = rows
          .map((r) => ScorerItem.fromRow(r, competitorNames: competitorNames, statType: mainType))
          .where((s) => s.athleteId != 0 && seen.add(s.athleteId))
          .toList(growable: false);
      result.sort((a, b) => b.value.compareTo(a.value));
      return result.take(50).toList(growable: false);
    }

    final rows = JsonTools.findBestList(
      json,
      looksLike: (m) => (m.containsKey('athlete') || m.containsKey('entity') || m.containsKey('athleteId')) &&
          (m.containsKey('mainStat') || m.containsKey('goals') || m.containsKey('value') || m.containsKey('stats')),
    );
    return rows
        .map((r) => ScorerItem.fromRow(r, competitorNames: competitorNames))
        .where((s) => s.athleteId != 0)
        .take(50)
        .toList(growable: false);
  }

  Map<int, Team> _teamLookup(Map<String, dynamic> json) {
    final out = <int, Team>{};
    final direct = JsonTools.list(json['competitors']);
    for (final item in direct) {
      final team = Team.fromJson(item);
      if (team.id != 0) out[team.id] = team;
    }
    return out;
  }

  Map<int, String> _competitorNames(Map<String, dynamic> json) {
    final out = <int, String>{};
    for (final item in JsonTools.list(json['competitors'])) {
      final id = JsonTools.intValue(item['id']);
      final name = '${item['name'] ?? ''}'.trim();
      if (id != 0 && name.isNotEmpty) out[id] = name;
    }
    return out;
  }

  Map<String, dynamic> _flattenStanding(Map<String, dynamic> raw) {
    final out = <String, dynamic>{...raw};
    for (final key in const ['stats', 'values', 'standing', 'tableRow', 'record']) {
      final nested = JsonTools.map(raw[key]);
      if (nested.isNotEmpty) out.addAll(nested);
    }
    return out;
  }

  bool _looksLikeStanding(Map<String, dynamic> m) {
    final hasTeam = m['competitor'] is Map || m['team'] is Map || m['entity'] is Map ||
        m.containsKey('competitorId') || m.containsKey('teamId') || m.containsKey('participantId');
    final hasTableValue = m.containsKey('position') || m.containsKey('rank') || m.containsKey('points') ||
        m.containsKey('gamesPlayed') || m.containsKey('played') || m.containsKey('wins');
    return hasTeam && hasTableValue;
  }

  int _standingQuality(StandingRow row) {
    var q = 0;
    if (row.position > 0) q += 3;
    if (row.points != 0) q += 3;
    if (row.played != 0) q += 2;
    if (row.wins != 0 || row.draws != 0 || row.losses != 0) q += 1;
    if (row.goalsFor != 0 || row.goalsAgainst != 0) q += 1;
    return q;
  }

  bool _looksLikeEvent(Map<String, dynamic> e) {
    final hasTime = e.containsKey('gameTime') || e.containsKey('gameTimeDisplay') || e.containsKey('minute') || e.containsKey('time');
    final hasType = e.containsKey('eventType') || e.containsKey('eventTypeId') || e.containsKey('type') || e.containsKey('eventText') || e.containsKey('eventName');
    final hasActor = e.containsKey('athlete') || e.containsKey('player') || e.containsKey('athleteId') || e.containsKey('competitorId');
    return hasTime && (hasType || hasActor);
  }

  Map<String, dynamic> _normalizeEvent(Map<String, dynamic> e) {
    final athlete = JsonTools.map(e['athlete'] ?? e['player'] ?? e['mainAthlete']);
    final competitor = JsonTools.map(e['competitor'] ?? e['team']);
    return {
      ...e,
      'minute': e['minute'] ?? e['gameTime'] ?? e['time'],
      'gameTime': e['gameTime'] ?? e['minute'] ?? e['time'],
      'athleteName': e['athleteName'] ?? e['playerName'] ?? athlete['name'] ?? athlete['shortName'],
      'athleteId': e['athleteId'] ?? athlete['id'],
      'competitorId': e['competitorId'] ?? competitor['id'] ?? athlete['competitorId'],
      'eventName': e['eventName'] ?? e['eventText'] ?? e['title'] ?? e['name'] ?? JsonTools.map(e['eventType'])['name'],
    };
  }

  bool _looksLikeLineupPlayer(Map<String, dynamic> e) {
    final athlete = JsonTools.map(e['athlete'] ?? e['player']);
    final hasId = e.containsKey('athleteId') || athlete.containsKey('id') || (e.containsKey('id') && (e.containsKey('jerseyNumber') || e.containsKey('position')));
    final hasPlayerData = athlete.isNotEmpty || e.containsKey('playerName') || e.containsKey('athleteName') || e.containsKey('jerseyNumber') || e.containsKey('formationPosition');
    return hasId && hasPlayerData;
  }

  Map<String, dynamic> _normalizeLineup(Map<String, dynamic> e) {
    final athlete = JsonTools.map(e['athlete'] ?? e['player']);
    final competitor = JsonTools.map(e['competitor'] ?? e['team']);
    return {
      ...e,
      'athlete': athlete.isEmpty ? e : athlete,
      'athleteId': e['athleteId'] ?? athlete['id'] ?? e['id'],
      'name': e['name'] ?? e['athleteName'] ?? e['playerName'] ?? athlete['name'],
      'jerseyNumber': e['jerseyNumber'] ?? athlete['jerseyNumber'] ?? athlete['shirtNumber'],
      'positionName': e['positionName'] ?? athlete['positionName'] ?? JsonTools.map(athlete['position'])['name'],
      'competitorId': e['competitorId'] ?? competitor['id'] ?? athlete['competitorId'] ?? athlete['clubId'],
      'isStarter': e['isStarter'] ?? e['starter'] ?? e['isStarting'] ?? true,
    };
  }

  List<Map<String, dynamic>> _dedupeLineup(List<Map<String, dynamic>> input) {
    final seen = <String>{};
    final out = <Map<String, dynamic>>[];
    for (final item in input) {
      final key = '${item['competitorId'] ?? ''}:${item['athleteId'] ?? item['id'] ?? ''}:${item['name'] ?? ''}';
      if (key != '::' && seen.add(key)) out.add(item);
    }
    return out;
  }

  bool _hasStatValues(Map<String, dynamic> m) {
    return m.containsKey('home') || m.containsKey('away') || m.containsKey('homeValue') || m.containsKey('awayValue') ||
        m.containsKey('homeCompetitorValue') || m.containsKey('awayCompetitorValue') || m.containsKey('values') || m.containsKey('competitors');
  }

  Map<String, dynamic> _normalizeStat(Map<String, dynamic> s) {
    final name = s['name'] ?? s['title'] ?? s['statName'] ?? s['displayName'] ?? s['shortName'];
    dynamic home = s['home'] ?? s['homeValue'] ?? s['homeCompetitorValue'] ?? s['value1'];
    dynamic away = s['away'] ?? s['awayValue'] ?? s['awayCompetitorValue'] ?? s['value2'];

    final values = s['values'];
    if ((home == null || away == null) && values is List && values.length >= 2) {
      home ??= values[0] is Map ? (values[0]['value'] ?? values[0]['statValue']) : values[0];
      away ??= values[1] is Map ? (values[1]['value'] ?? values[1]['statValue']) : values[1];
    }

    final competitors = JsonTools.list(s['competitors']);
    if ((home == null || away == null) && competitors.length >= 2) {
      home ??= competitors[0]['value'] ?? competitors[0]['statValue'];
      away ??= competitors[1]['value'] ?? competitors[1]['statValue'];
    }

    if (name == null || (home == null && away == null)) return const {};
    return {'name': '$name', 'home': home == null ? '' : '$home', 'away': away == null ? '' : '$away'};
  }

  Map<String, dynamic> _findEntity(Map<String, dynamic> json, {required int id, required Set<String> keys}) {
    for (final key in keys) {
      final direct = json[key];
      if (direct is Map) {
        final map = JsonTools.map(direct);
        if (JsonTools.intValue(map['id']) == id || id == 0) return map;
      }
      if (direct is List) {
        for (final item in JsonTools.list(direct)) {
          if (JsonTools.intValue(item['id']) == id) return item;
        }
      }
    }

    Map<String, dynamic> found = const {};
    void walk(dynamic value, int depth) {
      if (found.isNotEmpty || depth > 10) return;
      if (value is Map) {
        final map = JsonTools.map(value);
        if (JsonTools.intValue(map['id']) == id && (map.containsKey('name') || map.containsKey('shortName'))) {
          found = map;
          return;
        }
        for (final child in value.values) walk(child, depth + 1);
      } else if (value is List) {
        for (final child in value) walk(child, depth + 1);
      }
    }
    walk(json, 0);
    return found;
  }

  List<Map<String, dynamic>> _dedupeMaps(List<Map<String, dynamic>> input) {
    final seen = <String>{};
    final out = <Map<String, dynamic>>[];
    for (final item in input) {
      final key = '${item['id'] ?? item['eventId'] ?? ''}|${item['gameTime'] ?? item['minute'] ?? ''}|${item['eventName'] ?? item['name'] ?? item['eventType'] ?? ''}|${item['athleteId'] ?? JsonTools.map(item['athlete'])['id'] ?? ''}';
      if (seen.add(key)) out.add(item);
    }
    return out;
  }

  List<Map<String, dynamic>> _dedupeGames(List<Map<String, dynamic>> input) {
    final seen = <int>{};
    final out = <Map<String, dynamic>>[];
    for (final item in input) {
      final id = JsonTools.intValue(item['id'] ?? item['gameId']);
      if (id != 0 && seen.add(id)) out.add(item);
    }
    return out;
  }

  String _date(DateTime date) => '${date.day.toString().padLeft(2, '0')}/${date.month.toString().padLeft(2, '0')}/${date.year}';

  void dispose() => _client.close();
}

class MatchDetailsData {
  final Map<String, dynamic> raw;
  final Map<String, dynamic> game;
  final List<Map<String, dynamic>> events;
  final List<Map<String, dynamic>> lineups;
  final List<Map<String, dynamic>> stats;
  final Map<String, String> info;

  const MatchDetailsData({
    required this.raw,
    required this.game,
    required this.events,
    required this.lineups,
    required this.stats,
    required this.info,
  });
}

class TeamProfileData {
  final Team team;
  final List<PlayerItem> players;
  final List<MatchItem> matches;
  final Map<String, dynamic> raw;
  const TeamProfileData({required this.team, required this.players, required this.matches, required this.raw});
}

class PlayerProfileData {
  final PlayerItem player;
  final Map<String, dynamic> raw;
  const PlayerProfileData({required this.player, required this.raw});
}
