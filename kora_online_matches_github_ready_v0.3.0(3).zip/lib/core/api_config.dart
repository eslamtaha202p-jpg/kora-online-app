abstract final class ApiConfig {
  static const baseUrl = 'https://webws.365scores.com';
  static const imageBaseUrl = 'https://imagecache.365scores.com/image/upload';

  static Map<String, String> baseParams() => {
        'appTypeId': '5',
        'langId': '27',
        'timezoneName': 'Africa/Cairo',
        'userCountryId': '131',
      };

  static Uri uri(String path, [Map<String, String> extra = const {}]) {
    return Uri.parse('$baseUrl$path').replace(
      queryParameters: {...baseParams(), ...extra},
    );
  }

  static String competitorLogo({required int id, int size = 100}) =>
      '$imageBaseUrl/f_auto,w_$size,h_$size,c_limit,q_auto:eco/v1/Competitors/$id';

  static String athletePhoto({required int id, int size = 100}) =>
      '$imageBaseUrl/f_auto,w_$size,h_$size,c_limit,q_auto:eco/v1/Athletes/$id';

  static String competitionLogo({required int id, int imageVersion = 1, int size = 80}) =>
      '$imageBaseUrl/f_png,w_$size,h_$size,c_limit,q_auto:eco/v$imageVersion/Competitions/light/$id';
}
