import 'package:flutter/material.dart';

import '../core/app_theme.dart';
import '../data/favorites_store.dart';
import '../data/sports_repository.dart';
import '../models/competition.dart';
import '../widgets/app_states.dart';
import '../widgets/network_logo.dart';
import 'competition_details_screen.dart';

class CompetitionsScreen extends StatefulWidget {
  final SportsRepository repository;
  final FavoritesStore favorites;
  const CompetitionsScreen({super.key, required this.repository, required this.favorites});

  @override
  State<CompetitionsScreen> createState() => _CompetitionsScreenState();
}

class _CompetitionsScreenState extends State<CompetitionsScreen> {
  bool loading = true;
  Object? error;
  List<Competition> competitions = const [];
  String query = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() { loading = true; error = null; });
    try {
      final data = await widget.repository.fetchCompetitionsCatalog();
      if (!mounted) return;
      setState(() { competitions = data; loading = false; });
    } catch (e) {
      if (!mounted) return;
      setState(() { error = e; loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    final q = query.trim().toLowerCase();
    final visible = q.isEmpty ? competitions : competitions.where((c) => c.name.toLowerCase().contains(q)).toList(growable: false);
    return SafeArea(
      bottom: false,
      child: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 10),
          child: Row(children: [
            const Expanded(child: Text('البطولات', style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900))),
            IconButton(onPressed: _load, icon: const Icon(Icons.refresh_rounded)),
          ]),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: TextField(
            onChanged: (v) => setState(() => query = v),
            decoration: InputDecoration(
              hintText: 'ابحث عن بطولة',
              prefixIcon: const Icon(Icons.search),
              filled: true,
              fillColor: AppColors.surface,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide.none),
              enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: const BorderSide(color: AppColors.border)),
            ),
          ),
        ),
        const SizedBox(height: 12),
        Expanded(
          child: loading && competitions.isEmpty
              ? const AppLoading()
              : error != null && competitions.isEmpty
                  ? AppError(error: error!, onRetry: _load)
                  : RefreshIndicator(
                      onRefresh: _load,
                      child: visible.isEmpty
                          ? ListView(children: const [SizedBox(height: 250, child: EmptyState(text: 'لا توجد بطولات مطابقة'))])
                          : GridView.builder(
                              padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
                              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                                crossAxisCount: 2,
                                crossAxisSpacing: 10,
                                mainAxisSpacing: 10,
                                childAspectRatio: 1.35,
                              ),
                              itemCount: visible.length,
                              itemBuilder: (_, i) {
                                final c = visible[i];
                                return InkWell(
                                  onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => CompetitionDetailsScreen(repository: widget.repository, favorites: widget.favorites, competition: c))),
                                  borderRadius: BorderRadius.circular(17),
                                  child: Ink(
                                    padding: const EdgeInsets.all(13),
                                    decoration: BoxDecoration(color: AppColors.surface, borderRadius: BorderRadius.circular(17), border: Border.all(color: AppColors.border)),
                                    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                                      NetworkLogo(url: c.logoUrl, size: 46, fallbackIcon: Icons.emoji_events_outlined),
                                      const SizedBox(height: 8),
                                      Text(c.name, maxLines: 2, textAlign: TextAlign.center, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 11)),
                                    ]),
                                  ),
                                );
                              },
                            ),
                    ),
        ),
      ]),
    );
  }
}
